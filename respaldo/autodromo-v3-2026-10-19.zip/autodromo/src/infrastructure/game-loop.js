/** Ciclo de cuadros con paso acotado para que una pestaña lenta no teletransporte al auto. */
export function createGameLoop({
  onFrame,
  requestFrame = globalThis.requestAnimationFrame?.bind(globalThis),
  cancelFrame = globalThis.cancelAnimationFrame?.bind(globalThis),
  maxStep = 0.05
}) {
  let handle = null;
  let last = null;

  function frame(now) {
    const dt = last === null ? 0 : Math.min(maxStep, (now - last) / 1000);
    last = now;
    handle = requestFrame(frame);
    onFrame(dt);
  }

  return {
    start() {
      if (handle !== null) return;
      last = null;
      handle = requestFrame(frame);
    },
    stop() {
      if (handle === null) return;
      cancelFrame(handle);
      handle = null;
    },
    get running() { return handle !== null; }
  };
}
