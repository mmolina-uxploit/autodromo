import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createGameLoop } from '../../src/infrastructure/game-loop.js';

function fakeFrames() {
  let queue = [];
  let id = 0;
  return {
    requestFrame: cb => { queue.push({ id: ++id, cb }); return id; },
    cancelFrame: h => { queue = queue.filter(f => f.id !== h); },
    flush(now) { const current = queue; queue = []; current.forEach(f => f.cb(now)); },
    get pending() { return queue.length; }
  };
}

test('entrega el tiempo transcurrido en segundos, con tope', () => {
  const frames = fakeFrames();
  const steps = [];
  const loop = createGameLoop({ onFrame: dt => steps.push(dt), ...frames, maxStep: 0.05 });
  loop.start();
  frames.flush(1000);
  frames.flush(1016);
  frames.flush(2000);
  assert.deepEqual(steps.map(s => +s.toFixed(3)), [0, 0.016, 0.05]);
});

test('stop detiene el ciclo y start no duplica', () => {
  const frames = fakeFrames();
  const loop = createGameLoop({ onFrame() {}, ...frames });
  loop.start();
  loop.start();
  assert.equal(frames.pending, 1);
  loop.stop();
  assert.equal(frames.pending, 0);
  assert.equal(loop.running, false);
});
