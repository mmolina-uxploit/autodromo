# Decisiones de arquitectura

## 1. Clean Architecture con dominio funcional

**Contexto.** La primera versión tenía física, dibujo, entrada y menús en un solo archivo. Cualquier cambio podía romper cualquier cosa y nada se podía probar sin un navegador.

**Decisión.** Cuatro capas con la regla de dependencias apuntando al dominio. El dominio es un conjunto de funciones puras sobre estado inmutable: `estado + controles + dt → estado + eventos`.

**Consecuencias.** El dominio se prueba en milisegundos con Node, sin navegador. Una prueba de arquitectura impide que la regla se erosione. El costo es un poco de asignación de memoria por cuadro, irrelevante con 140 autos.

## 2. Motor en JavaScript, no en C++

**Contexto.** Se evaluó escribir el motor de lógica en C++ y compilarlo a WebAssembly.

**Decisión.** JavaScript.

**Razones.**
- La simulación cuesta microsegundos por cuadro. El tiempo de cada cuadro se va en dibujar el canvas, y C++ no acelera ese dibujo.
- WebAssembly agregaría un paso de compilación (Emscripten) y un límite entre lenguajes que hay que serializar en cada cuadro.
- GitHub Pages hoy publica el repositorio tal cual; con C++ habría que compilar antes de cada publicación.

**Cuándo revisarla.** C++ tiene sentido si el mismo motor va a correr en una app nativa (iOS con interoperabilidad Swift–C++, Android vía NDK). El dominio ya está aislado detrás de `stepRace` y sus pruebas describen el contrato. Portarlo implica reescribir `src/domain/` en C++, traducir las pruebas y cambiar solo `application/race-session.js` para que llame al módulo WebAssembly.

## 3. Sin dependencias en producción

**Decisión.** Ni framework de UI ni bundler. Módulos ES nativos y una función `h()` de 20 líneas para crear elementos.

**Consecuencias.** Cero pasos de compilación, cero actualizaciones de seguridad de terceros en lo que llega al jugador. Playwright y axe-core son dependencias de desarrollo y solo corren en CI.

## 4. Atomic Design con componentes de función

**Decisión.** Cada componente es una función que devuelve su elemento y, si hace falta, métodos para actualizarlo (`set`, `update`). Los niveles se reflejan en carpetas y en prefijos CSS.

**Consecuencias.** Los componentes no conocen el juego. La página es la única pieza que traduce eventos de la sesión en interfaz, y los organismos reciben callbacks.

## 5. Coherencia visual verificada por pruebas

**Decisión.** `design/ecosistema.json` es la fuente única de colores, zonas y libreas. Una prueba compara contra él la configuración del juego, los tokens CSS y el atlas de sprites.

**Consecuencias.** Un cambio de color hecho a mano en el código, o una librea sin sprites, rompe la build en lugar de llegar a producción.

## 6. Selección de auto y pista

**Contexto.** Elegir auto y pista solo tiene sentido si la elección cambia la carrera. Un cambio cosmético no justifica una pantalla.

**Decisión.**
- Cada auto define un rendimiento que ajusta la física del jugador: velocidad máxima, aceleración, giro, agarre en curva y cuánta velocidad conserva al chocar.
- Cada pista combina un trazado propio con una zona del ecosistema.
- La mejor vuelta se guarda por par de pista y auto.

**Consecuencias.**
- El rendimiento se valida en el dominio (`vehiclePerformance`) y nunca toca el tráfico, así que la dificultad de la pista no depende del auto elegido.
- La sesión reconstruye el mundo solo mientras la carrera espera la largada. Una selección pendiente se aplica al salir al menú.
- Las estadísticas de 1 a 5 se derivan del rendimiento, así que retocar un auto actualiza su tarjeta sin editar textos.
