# Autódromo

Juego de carreras pseudo-3D para navegador. JavaScript nativo con módulos ES, sin dependencias en producción y sin paso de compilación: el repositorio se publica tal cual en GitHub Pages.

## Correr, probar y publicar

| Qué | Cómo |
|---|---|
| Jugar en local | `npm run serve` y abrir `http://localhost:8080`. Los módulos ES necesitan servidor: abrir `index.html` con doble clic no funciona. Con `?semilla=7` en la URL el tráfico se repite igual en cada carrera. |
| Pruebas unitarias, de arquitectura y de coherencia | `npm test`. No requiere instalar nada; usa el corredor de pruebas de Node 20+. |
| Pruebas de punta a punta | `npm install`, `npx playwright install chromium` y `npm run e2e`. Deja capturas en `tests/e2e/capturas/`. |
| Publicar | Push a `main`. En el repositorio: Settings → Pages → Source: **GitHub Actions**. La publicación solo ocurre si todas las pruebas pasan. |
| Regenerar sprites | `pip install numpy scipy pillow` y `npm run sprites`. Por etapas: `npm run sprites -- sprites --modelos saeta`, `retratos`, `hojas` o `tablero`. |

## Autos y pistas

El jugador elige auto, color y pista desde el inicio. La combinación queda guardada, y la mejor vuelta se registra por separado para cada par de pista y auto.

| Auto | Carácter | Velocidad | Aceleración | Manejo | Resistencia |
|---|---|---|---|---|---|
| Cuña | La más rápida en recta; pide frenar antes de cada curva | 5 | 3 | 3 | 2 |
| Saeta | Sale disparada y dobla firme; un choque la frena en seco | 3 | 5 | 4 | 1 |
| Bloque | Lento y pesado; pasa entre el tráfico casi sin perder velocidad | 2 | 3 | 2 | 5 |

Las cifras no se escriben a mano: `application/selection-presenters.js` las calcula a partir del rendimiento de cada auto en `config/vehicles.js`. El rendimiento ajusta solo la física del jugador (`domain/vehicle.js`); el tráfico conserva las reglas base.

| Pista | Zona | Trazado |
|---|---|---|
| Bajo Autopista | Noche bajo el viaducto | Equilibrada: curvas medias y lomas suaves |
| Costa Rosa | Día junto al mar | Rápida: curvas largas y casi sin desnivel |
| Distrito Torre | Día entre torres | Técnica: curvas encadenadas |
| Anillo Neón | Noche de neón | Exigente: lomas altas que esconden curvas cerradas |

Cada tarjeta de pista muestra el perfil de altura, el largo, la cantidad de curvas y el desnivel, todo calculado desde el trazado en `config/tracks.js`.

## Arquitectura

El código sigue Clean Architecture: las reglas del juego viven en el centro y no conocen el navegador. Cada capa externa depende de las internas, nunca al revés.

```
src/
├── domain/          Reglas puras: pista, física, tráfico, choques, vueltas, carrera
├── application/     Casos de uso y puertos: sesión de carrera, ajustes, presentadores
├── infrastructure/  Adaptadores: teclado, táctil, almacenamiento, vibración, ciclo, canvas
├── presentation/    Interfaz con Atomic Design
├── config/          Datos: reglas, trazado, zonas, cámara
└── main.js          Raíz de composición: el único archivo que conoce todas las capas
```

| Capa | Puede importar de |
|---|---|
| `domain` | `domain` |
| `config` | `config` |
| `application` | `application`, `domain` |
| `infrastructure` | `infrastructure`, `application`, `domain`, `config` |
| `presentation` | `presentation`, `application`, `config` |

`tests/architecture.test.js` hace cumplir esta tabla: un import que la viole rompe la build. La misma prueba impide que el dominio use `window`, `document`, `localStorage` o cualquier API del navegador.

El dominio es funcional e inmutable. `stepRace(carrera, controles, dt, mundo)` recibe un estado y devuelve otro más una lista de eventos; no muta nada ni produce efectos. Los efectos (guardar la mejor vuelta, vibrar al chocar) los decide `application/race-session.js` y los ejecutan adaptadores detrás de puertos (`application/ports.js`). La presentación recibe por inyección lo que necesita de la infraestructura, por ejemplo `bindHold` para los controles táctiles.

## Pruebas y TDD

Cada capa se escribió en el ciclo rojo → verde → refactor: primero las pruebas que describen el comportamiento, luego el código mínimo que las pasa, después la limpieza con las pruebas como red.

| Nivel | Qué cubre | Dónde |
|---|---|---|
| Unitarias | Física, pista, tráfico, choques, vueltas, cuenta regresiva, pausa, sesión, ajustes, presentadores, entrada, almacenamiento, proyección, atlas | `tests/domain`, `tests/application`, `tests/infrastructure` |
| De sistema | Regla de dependencias entre capas y coherencia con el ecosistema visual | `tests/architecture.test.js`, `tests/design-coherence.test.js` |
| Punta a punta | Navegador real en escritorio y dos celulares: teclado, multitoque, foco, desborde y auditoría WCAG con axe | `tests/e2e/smoke.mjs` |

El generador de números aleatorios es determinista (`domain/rng.js`), así que el tráfico es reproducible en las pruebas. Para continuar con TDD, `npm run test:watch` vuelve a correr las pruebas en cada cambio.

## Interfaz con Atomic Design

| Nivel | Archivos | Prefijo CSS |
|---|---|---|
| Átomos | `Button`, `PadButton`, `Switch`, `RadioChip`, `Readout`, `Icon`, `LiveRegion`, `Meter`, `Picture`, `ProfileGraphic`, tipografía | `a-` |
| Moléculas | `Stat`, `ChoiceGroup`, `SettingRow`, `PadCluster`, `KeyList`, `Toast`, `Countdown`, `OptionCard`, `SummaryTile`, `StatMeters`, `FactList` | `m-` |
| Organismos | `Hud`, `TouchControls`, `StartMenu`, `CarSelect`, `TrackSelect`, `PauseMenu`, `SettingsPanel`, `HelpPanel`, `DialogPanel` | `o-` |
| Plantilla | `RaceLayout` | `t-` |
| Página | `race-page.js` | — |

Los estilos siguen la misma división (`styles/atoms.css`, `molecules.css`, `organisms.css`, `templates.css`) y toman todos sus valores de `styles/tokens.css`. Cada color de los tokens sale de la paleta de `design/ecosistema.json`; `tests/design-coherence.test.js` falla si aparece uno ajeno, si una zona del juego se desvía del ecosistema o si falta un cuadro de sprite.

## Accesibilidad y uso

**Selección.** Las tarjetas de auto y de pista son radios nativos que cubren toda la tarjeta: se eligen con un toque, con clic o con flechas. El nombre accesible es el título de la tarjeta y la descripción es su texto corto, así el lector no recita la tarjeta entera. Las estadísticas son medidores (`role="meter"`) que anuncian «4 de 5». Elegir un color con flechas no le quita el foco al grupo.

**Teclado.** Flechas o WASD para manejar (WASD por posición física, así funciona en cualquier distribución), Espacio para frenar, Escape o P para pausar. Los menús se recorren con Tab y las opciones con flechas, porque son radios nativos. Cada diálogo pone el foco en su acción principal y, al cerrarse, lo devuelve a la pista.

**Táctil.** Botones de mantener presionado con Pointer Events y captura de puntero: admiten varios dedos a la vez y no se sueltan al deslizar. Miden 76 y 96 px (68 y 84 px en pantallas de 360 px o menos). Los controles táctiles aparecen solo en dispositivos con puntero grueso.

**Ajustes de accesibilidad.**
- Aceleración automática, para jugar con una mano.
- Controles invertidos, para zurdos.
- Vibración al chocar, desactivable.
- Movimiento reducido, que quita sacudidas y animaciones. Arranca activado si el sistema lo pide.

**Lectores de pantalla.**
- Una región en vivo anuncia la cuenta regresiva, la largada, cada vuelta con su tiempo, los choques y la pausa.
- El canvas queda oculto para el lector porque el tablero ya transmite toda la información en texto.

**Otros.**
- Los menús usan `<dialog>` nativo, que vuelve inerte el fondo y gestiona Escape.
- El zoom del navegador no está bloqueado.
- La carrera se pausa sola al cambiar de pestaña.
- El contraste supera WCAG AA en todos los textos.

## Diseño visual

`design/` contiene el ecosistema visual del que sale todo el aspecto del juego:
- `referencias-estilo.json`, el análisis de las referencias.
- `ecosistema.json`, la paleta, las zonas, las libreas y el contrato de sprites.
- El generador de sprites.
- Las hojas de modelo de cada auto.

Las decisiones de arquitectura están en [`docs/decisiones.md`](docs/decisiones.md).

Para reemplazar los sprites por arte hecho a mano o con IA generativa, la especificación está en [`docs/brief-sprites.md`](docs/brief-sprites.md) y los 232 nombres de archivo en [`docs/lista-archivos-sprites.md`](docs/lista-archivos-sprites.md).
