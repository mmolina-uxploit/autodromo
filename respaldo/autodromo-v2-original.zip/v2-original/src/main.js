/**
 * Raíz de composición: el único lugar que conoce todas las capas y las conecta.
 */
import { createRules } from './config/rules.js';
import { CAMERA } from './config/camera.js';
import { TRAFFIC_VARIANTS, findZone } from './config/zones.js';
import { TRACKS, findTrack } from './config/tracks.js';
import { VEHICLES, findVehicle, findLivery } from './config/vehicles.js';
import { Track } from './domain/track.js';
import { createRng } from './domain/rng.js';
import { createRaceSession } from './application/race-session.js';
import { createSettingsStore } from './application/settings-store.js';
import { createActionSet } from './application/action-set.js';
import { describeTrack } from './application/selection-presenters.js';
import { SessionEvent } from './application/race-events.js';
import { createBestLapRepository, createSettingsRepository } from './infrastructure/storage.js';
import { createHaptics } from './infrastructure/haptics.js';
import { createGameLoop } from './infrastructure/game-loop.js';
import { bindKeyboard, Command } from './infrastructure/input/keyboard.js';
import { bindHoldControl } from './infrastructure/input/touch.js';
import { createCanvasRenderer } from './infrastructure/rendering/canvas-renderer.js';
import { loadSpriteAtlas } from './infrastructure/rendering/sprite-atlas.js';
import { createRacePage } from './presentation/pages/race-page.js';

function safeLocalStorage() {
  try { return window.localStorage; } catch { return undefined; }
}

/** ?semilla=123 fija el tráfico para reproducir una carrera; sin ella cada carrera es distinta. */
function seedSource() {
  const fixed = Number.parseInt(new URLSearchParams(window.location.search).get('semilla'), 10);
  return Number.isInteger(fixed) ? () => fixed : () => Date.now();
}

const nextSeed = seedSource();
const rules = createRules();
const storage = safeLocalStorage();
const tracks = new Map(TRACKS.map(t => [t.id, Track.fromLayout(t.layout, rules)]));

const settingsStore = createSettingsStore({
  repository: createSettingsRepository(storage),
  catalog: {
    tracks: TRACKS.map(t => t.id),
    vehicles: VEHICLES.map(v => v.id),
    liveries: Object.fromEntries(VEHICLES.map(v => [v.id, v.liveries.map(l => l.id)])),
    prefersReducedMotion: window.matchMedia('(prefers-reduced-motion: reduce)').matches
  }
});

const actions = createActionSet();
const session = createRaceSession({
  tracks,
  vehicles: VEHICLES,
  rules,
  createRng: () => createRng(nextSeed()),
  trafficVariants: TRAFFIC_VARIANTS.length,
  bestLapRepository: createBestLapRepository(storage),
  haptics: createHaptics(navigator),
  getSettings: () => settingsStore.current
});

const canvas = document.createElement('canvas');
const renderer = createCanvasRenderer(canvas, { rules, cameraConfig: CAMERA });

const page = createRacePage({
  root: document.getElementById('app'),
  canvas,
  session,
  settingsStore,
  rules,
  vehicles: VEHICLES,
  tracks: TRACKS.map(t => ({ ...t, zone: findZone(t.zone), info: describeTrack(tracks.get(t.id), rules) })),
  actions,
  bindHold: bindHoldControl
});

function applyWorld() {
  const { track, trackId } = session.world;
  renderer.setTrack(track);
  renderer.setZone(findZone(findTrack(trackId).zone));
}

function applySettings(settings) {
  session.syncSelection();
  const vehicle = findVehicle(settings.vehicle);
  const livery = findLivery(vehicle, settings.livery);
  renderer.setVehicle({ model: vehicle.model, livery: livery.id, swatch: livery.swatch });
  renderer.setReducedMotion(settings.reducedMotion);
}

session.subscribe(event => { if (event.type === SessionEvent.WORLD_CHANGED) applyWorld(); });
settingsStore.subscribe(applySettings);
applyWorld();
applySettings(settingsStore.current);

bindKeyboard(window, {
  actions,
  isGameActive: page.isGameActive,
  onCommand: command => { if (command === Command.PAUSE) page.requestPause(); }
});
window.addEventListener('blur', () => actions.releaseAll());

const loop = createGameLoop({
  onFrame(dt) {
    const result = session.tick(dt, actions.snapshot());
    renderer.render(result.state, { controls: result.controls, dt });
    page.onFrame(result);
  }
});

new ResizeObserver(() => renderer.resize()).observe(canvas);
renderer.resize();
loop.start();

document.addEventListener('visibilitychange', () => (document.hidden ? loop.stop() : loop.start()));

loadSpriteAtlas('assets/sprites')
  .then(atlas => renderer.setAtlas(atlas))
  .catch(error => console.warn('Sprites no disponibles; se usa el dibujo de respaldo.', error));
