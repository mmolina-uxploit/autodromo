import { createCamera, createViewport, projectPoint, fogAt, spriteScale } from './projection.js';
import { findFrame, steerFrameIndex } from './sprite-atlas.js';
import { paintBackdrop } from './backdrop.js';
import { paintProp, propAt } from './props.js';
import { paintFallbackCar } from './car-painter.js';
import { START_LINE_COLOR, TRAFFIC_VARIANTS } from '../../config/zones.js';
import { lerp } from '../../domain/math.js';
import { isOffRoad } from '../../domain/player.js';

const FALLBACK_TRAFFIC_COLORS = ['#7f93b0', '#5f6b78', '#d8509a', '#e9e2d3', '#3fb3b0', '#e0b54a'];
const hexToRgb = hex => [1, 3, 5].map(i => parseInt(hex.slice(i, i + 2), 16)).join(',');

/**
 * Adaptador de salida: dibuja el estado de la carrera en un canvas 2D.
 * No decide nada del juego; solo traduce estado a píxeles.
 */
export function createCanvasRenderer(canvas, { rules, cameraConfig }) {
  const ctx = canvas.getContext('2d', { alpha: false });
  const camera = createCamera(cameraConfig);
  const slots = Array.from({ length: camera.drawDistance }, () => ({ segment: null, p1: {}, p2: {}, clip: 0 }));
  let track = null;
  let segLen = rules.segmentLength;
  let buckets = [];
  const eye = { x: 0, y: 0, z: 0 };
  const point = { x: 0, y: 0, z: 0 };
  const view = {
    viewport: createViewport(1, 1, cameraConfig),
    atlas: null,
    zone: null,
    fogRgb: '0,0,0',
    model: null,
    livery: null,
    swatch: '#b6e03a',
    reducedMotion: false,
    skyOffset: 0,
    clock: 0
  };

  function resize() {
    const ratio = Math.min(globalThis.devicePixelRatio || 1, cameraConfig.maxPixelRatio);
    const width = Math.max(1, Math.round(canvas.clientWidth * ratio));
    const height = Math.max(1, Math.round(canvas.clientHeight * ratio));
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }
    view.viewport = createViewport(width, height, cameraConfig);
    ctx.imageSmoothingQuality = 'high';
  }

  function project(out, height, z, eyeX, eyeZ) {
    point.y = height;
    point.z = z;
    eye.x = eyeX;
    eye.z = eyeZ;
    return projectPoint(out, point, eye, camera, view.viewport, rules.roadHalfWidth);
  }

  function polygon(x1, y1, x2, y2, x3, y3, x4, y4, color) {
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.lineTo(x3, y3);
    ctx.lineTo(x4, y4);
    ctx.closePath();
    ctx.fill();
  }

  function paintSegment({ segment, p1, p2 }, n) {
    const road = view.zone.road;
    const band = segment.band;
    const { width } = view.viewport;
    const r1 = p1.w / 6;
    const r2 = p2.w / 6;

    ctx.fillStyle = road.ground[band];
    ctx.fillRect(0, p2.y, width, p1.y - p2.y);
    polygon(p1.x - p1.w - r1, p1.y, p1.x - p1.w, p1.y, p2.x - p2.w, p2.y, p2.x - p2.w - r2, p2.y, road.rumble[band]);
    polygon(p1.x + p1.w + r1, p1.y, p1.x + p1.w, p1.y, p2.x + p2.w, p2.y, p2.x + p2.w + r2, p2.y, road.rumble[band]);
    polygon(p1.x - p1.w, p1.y, p1.x + p1.w, p1.y, p2.x + p2.w, p2.y, p2.x - p2.w, p2.y,
      segment.isStartLine ? START_LINE_COLOR : road.asphalt[band]);

    if (band === 0) {
      const l1 = p1.w / 32;
      const l2 = p2.w / 32;
      const step1 = (p1.w * 2) / rules.lanes;
      const step2 = (p2.w * 2) / rules.lanes;
      for (let lane = 1; lane < rules.lanes; lane++) {
        const x1 = p1.x - p1.w + step1 * lane;
        const x2 = p2.x - p2.w + step2 * lane;
        polygon(x1 - l1 / 2, p1.y, x1 + l1 / 2, p1.y, x2 + l2 / 2, p2.y, x2 - l2 / 2, p2.y, road.lane);
      }
    }

    const fog = fogAt(n, camera.drawDistance, camera.fogDensity);
    if (fog > 0.01) {
      ctx.fillStyle = `rgba(${view.fogRgb},${fog.toFixed(3)})`;
      ctx.fillRect(0, p2.y, width, p1.y - p2.y);
    }
  }

  function paintRoad(player, cameraZ, base, basePercent) {
    let maxY = view.viewport.height;
    let x = 0;
    let dx = -(base.curve * basePercent);
    const playerX = player.x * rules.roadHalfWidth;
    for (let n = 0; n < camera.drawDistance; n++) {
      const slot = slots[n];
      const segment = track.segment(base.index + n);
      const eyeZ = cameraZ - (segment.index < base.index ? track.length : 0);
      slot.segment = segment;
      project(slot.p1, segment.startHeight, segment.index * segLen, playerX - x, eyeZ);
      project(slot.p2, segment.endHeight, (segment.index + 1) * segLen, playerX - x - dx, eyeZ);
      x += dx;
      dx += segment.curve;
      slot.clip = maxY;
      const hidden = slot.p1.cameraZ <= camera.depth || slot.p2.y >= slot.p1.y || slot.p2.y >= maxY;
      if (hidden) continue;
      paintSegment(slot, n);
      maxY = slot.p1.y;
    }
  }

  function drawFrame({ image, rect }, x, y, scale, clipY) {
    const { atlas, viewport } = view;
    const clipped = clipY !== undefined && y > clipY;
    if (clipped) {
      ctx.save();
      ctx.beginPath();
      ctx.rect(0, 0, viewport.width, clipY);
      ctx.clip();
    }
    ctx.drawImage(image, rect.x, rect.y, rect.w, rect.h,
      x - atlas.anchorX * scale, y - atlas.anchorY * scale, rect.w * scale, rect.h * scale);
    if (clipped) ctx.restore();
  }

  function drawCar(spec, x, y, projectionScale, clipY, fallbackColor) {
    const { atlas, viewport } = view;
    if (!atlas) {
      if (clipY === undefined || y <= clipY) {
        paintFallbackCar(ctx, x, y, projectionScale * rules.roadHalfWidth * viewport.unit / 2 * 0.36, fallbackColor);
      }
      return;
    }
    const frame = findFrame(atlas, { ...spec, steerIndex: steerFrameIndex(spec.lean, atlas.steerAngles.length) });
    if (!frame) return;
    const scale = spriteScale(projectionScale, viewport, rules.worldUnitsPerMeter, atlas.pixelsPerMeter);
    if (frame.rect.w * scale < 4) return;
    drawFrame(frame, x, y, scale, clipY);
  }

  function paintTrafficCar({ segment, p1, p2, clip }, car) {
    const { viewport } = view;
    const t = (car.z % segLen) / segLen;
    const scale = lerp(p1.scale, p2.scale, t);
    const x = lerp(p1.x, p2.x, t) + scale * car.x * rules.roadHalfWidth * viewport.unit / 2;
    const y = lerp(p1.y, p2.y, t);
    const variant = TRAFFIC_VARIANTS[car.variant % TRAFFIC_VARIANTS.length];
    const incline = segment.endHeight - segment.startHeight > segLen * 0.15 ? 'subida' : 'plano';
    const lean = -(x - viewport.width / 2) / (viewport.width / 2);
    drawCar({ model: variant.model, livery: variant.livery, incline, light: 'luz', lean }, x, y, scale, clip,
      FALLBACK_TRAFFIC_COLORS[car.variant % FALLBACK_TRAFFIC_COLORS.length]);
  }

  function paintSprites(traffic) {
    const { viewport, zone } = view;
    for (const car of traffic) buckets[track.indexAt(car.z)].push(car);
    for (let n = camera.drawDistance - 1; n > 0; n--) {
      const slot = slots[n];
      if (slot.p1.cameraZ <= camera.depth) continue;
      ctx.globalAlpha = 1 - fogAt(n, camera.drawDistance, camera.fogDensity);
      const prop = propAt(slot.segment.index);
      if (prop) {
        const { p1 } = slot;
        const half = p1.scale * rules.roadHalfWidth * viewport.unit / 2;
        paintProp(ctx, zone.prop, p1.x + prop.offset * half, p1.y, half * prop.size, zone, slot.clip, viewport.width);
      }
      for (const car of buckets[slot.segment.index]) paintTrafficCar(slot, car);
    }
    ctx.globalAlpha = 1;
    for (const car of traffic) buckets[track.indexAt(car.z)].length = 0;
  }

  function paintPlayer(race, controls, playerY) {
    const { viewport } = view;
    const player = race.player;
    const speedRatio = player.speed / rules.maxSpeed;
    const motion = view.reducedMotion ? 0 : 1;
    const shakeAmount = (race.impact > 0 ? 10 : isOffRoad(player) ? 4 : 0) * speedRatio * motion;
    const shake = shakeAmount ? (Math.random() - 0.5) * shakeAmount : 0;
    const bounce = Math.sin(view.clock * 38) * speedRatio * 1.5 * motion;
    const rise = track.heightAt(player.z + segLen * 6) - playerY;
    drawCar({
      model: view.model,
      livery: view.livery,
      incline: rise > segLen * 0.9 ? 'subida' : 'plano',
      light: controls.brake > 0 && player.speed > 0 ? 'freno' : 'luz',
      lean: controls.steer * Math.min(1, speedRatio * 1.5) * (2 / 3)
    }, viewport.width / 2 + shake, viewport.horizon + viewport.height / 2 + bounce,
    camera.depth / camera.offset, undefined, view.swatch);
  }

  return {
    resize,
    setAtlas(atlas) { view.atlas = atlas; },
    setZone(zone) { view.zone = zone; view.fogRgb = hexToRgb(zone.fog); },
    setTrack(next) {
      track = next;
      segLen = next.segmentLength;
      buckets = Array.from({ length: next.segmentCount }, () => []);
    },
    setVehicle({ model, livery, swatch }) {
      view.model = model;
      view.livery = livery;
      view.swatch = swatch;
    },
    setReducedMotion(value) { view.reducedMotion = value; },

    render(race, { controls, dt }) {
      if (!view.zone || !track) return;
      const player = race.player;
      view.clock += dt;
      view.skyOffset += track.segmentAt(player.z).curve * (player.speed / rules.maxSpeed) * dt * view.viewport.width * 0.06;

      const cameraZ = track.wrap(player.z - camera.offset);
      const base = track.segmentAt(cameraZ);
      const playerY = track.heightAt(player.z);
      eye.y = playerY + camera.height;

      paintBackdrop(ctx, view.zone, view.viewport, view.skyOffset);
      paintRoad(player, cameraZ, base, (cameraZ % segLen) / segLen);
      paintSprites(race.traffic);
      paintPlayer(race, controls, playerY);
    }
  };
}
