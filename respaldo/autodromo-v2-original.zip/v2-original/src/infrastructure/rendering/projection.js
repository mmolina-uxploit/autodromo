export function createCamera({ height, fieldOfView, drawDistance, fogDensity }) {
  const depth = 1 / Math.tan(((fieldOfView / 2) * Math.PI) / 180);
  return Object.freeze({ height, depth, offset: height * depth, drawDistance, fogDensity });
}

export function createViewport(width, height, { horizonRatio = 0.32, unitRatio = 0.62 } = {}) {
  return Object.freeze({
    width,
    height,
    horizon: height * horizonRatio,
    unit: Math.min(width, height * unitRatio)
  });
}

/** Proyecta un punto del mundo a pantalla. Escribe en `out` para no asignar memoria por cuadro. */
export function projectPoint(out, world, eye, camera, viewport, roadHalfWidth) {
  const cameraZ = world.z - eye.z;
  const scale = camera.depth / cameraZ;
  out.cameraZ = cameraZ;
  out.scale = scale;
  out.x = Math.round(viewport.width / 2 + scale * (world.x - eye.x) * viewport.unit / 2);
  out.y = Math.round(viewport.horizon - scale * (world.y - eye.y) * viewport.height / 2);
  out.w = Math.round(scale * roadHalfWidth * viewport.unit / 2);
  return out;
}

export const fogAt = (n, drawDistance, density) => 1 - 1 / Math.exp(Math.pow(n / drawDistance, 2) * density);

/** Factor para dibujar un sprite medido en px/m a la escala del mundo en esa profundidad. */
export function spriteScale(projectionScale, viewport, worldUnitsPerMeter, pixelsPerMeter) {
  return projectionScale * (viewport.unit / 2) * (worldUnitsPerMeter / pixelsPerMeter);
}
