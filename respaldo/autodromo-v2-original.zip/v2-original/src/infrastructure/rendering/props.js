/** Elementos al costado de la pista: siluetas planas de un solo color (patrón P8 del ecosistema). */
const EVERY = 8;

export function propAt(index) {
  if (index % EVERY !== 4) return null;
  const side = Math.floor(index / EVERY) % 2 ? -1 : 1;
  return { offset: side * (1.4 + ((index * 7) % 10) / 12), size: 0.85 + ((index * 13) % 5) / 12 };
}

const PROPS = {
  pillar(ctx, x, y, s, zone) {
    const w = s * 0.09;
    const h = s * 1.1;
    ctx.fillStyle = '#4f5d7a';
    ctx.fillRect(x - w / 2, y - h, w, h);
    ctx.fillRect(x - w / 2, y - h, s * 0.22, w * 0.6);
    ctx.fillStyle = zone.accent;
    ctx.beginPath();
    ctx.arc(x - w / 2 + s * 0.2, y - h + w * 0.9, s * 0.045, 0, Math.PI * 2);
    ctx.fill();
  },
  palm(ctx, x, y, s) {
    const top = { x: x + s * 0.1, y: y - s * 1.1 };
    ctx.strokeStyle = '#e48ad8';
    ctx.lineCap = 'round';
    ctx.lineWidth = Math.max(1.5, s * 0.05);
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.quadraticCurveTo(x - s * 0.05, y - s * 0.6, top.x, top.y);
    ctx.stroke();
    ctx.lineWidth = Math.max(1.5, s * 0.06);
    for (const angle of [-2.7, -2.1, -1.4, -0.7, -0.1]) {
      ctx.beginPath();
      ctx.moveTo(top.x, top.y);
      ctx.lineTo(top.x + Math.cos(angle) * s * 0.42, top.y + Math.sin(angle) * s * 0.12 + s * 0.14);
      ctx.stroke();
    }
  },
  tree(ctx, x, y, s) {
    ctx.fillStyle = '#353a6e';
    ctx.fillRect(x - s * 0.025, y - s * 0.35, s * 0.05, s * 0.35);
    ctx.fillStyle = '#b6e03a';
    ctx.beginPath();
    ctx.arc(x, y - s * 0.6, s * 0.28, 0, Math.PI * 2);
    ctx.fill();
  },
  beacon(ctx, x, y, s, zone) {
    ctx.fillStyle = '#353a6e';
    ctx.fillRect(x - s * 0.02, y - s * 1.2, s * 0.04, s * 1.2);
    ctx.fillStyle = zone.accent;
    ctx.fillRect(x - s * 0.07, y - s * 1.28, s * 0.14, s * 0.1);
  }
};

export function paintProp(ctx, kind, x, y, scaleBase, zone, clipY, viewportWidth) {
  if (scaleBase < 3) return;
  const clipped = y > clipY;
  if (clipped) {
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, 0, viewportWidth, clipY);
    ctx.clip();
  }
  PROPS[kind]?.(ctx, x, y, scaleBase, zone);
  if (clipped) ctx.restore();
}
