/** Auto vectorial de respaldo mientras el atlas de sprites carga o si falla. */
export function paintFallbackCar(ctx, x, y, width, color) {
  const h = width * 0.52;
  ctx.save();
  ctx.translate(x, y);
  ctx.fillStyle = 'rgba(28,31,58,.35)';
  ctx.beginPath();
  ctx.ellipse(0, 0, width * 0.56, h * 0.13, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = '#1c1f3a';
  ctx.fillRect(-width * 0.5, -h * 0.34, width * 0.16, h * 0.34);
  ctx.fillRect(width * 0.34, -h * 0.34, width * 0.16, h * 0.34);
  ctx.fillStyle = color;
  ctx.fillRect(-width * 0.46, -h * 0.64, width * 0.92, h * 0.5);
  ctx.beginPath();
  ctx.moveTo(-width * 0.34, -h * 0.64);
  ctx.lineTo(-width * 0.25, -h);
  ctx.lineTo(width * 0.25, -h);
  ctx.lineTo(width * 0.34, -h * 0.64);
  ctx.closePath();
  ctx.fill();
  ctx.fillStyle = '#ff7a24';
  ctx.fillRect(-width * 0.45, -h * 0.56, width * 0.17, h * 0.13);
  ctx.fillRect(width * 0.28, -h * 0.56, width * 0.17, h * 0.13);
  ctx.restore();
}
