export function parseAtlas(json) {
  const sheets = Object.fromEntries(Object.entries(json.hojas).map(([model, sheet]) =>
    [model, Object.freeze({ file: sheet.archivo, frames: sheet.cuadros, image: null })]));
  return Object.freeze({
    frameWidth: json.cuadro.ancho,
    frameHeight: json.cuadro.alto,
    anchorX: json.cuadro.ancla[0],
    anchorY: json.cuadro.ancla[1],
    pixelsPerMeter: json.px_por_metro_en_ancla,
    steerAngles: json.giros_grados,
    sheets: Object.freeze(sheets)
  });
}

export function steerFrameIndex(value, frameCount) {
  const t = (Math.min(1, Math.max(-1, value)) + 1) / 2;
  return Math.round(t * (frameCount - 1));
}

export const frameKey = ({ model, livery, incline, light, steerIndex }) =>
  `${model}_${livery}_${incline}_${light}_g${steerIndex}`;

/** Busca el cuadro pedido; si no existe, cae en luz normal y luego en terreno plano. */
export function findFrame(atlas, spec) {
  const sheet = atlas.sheets[spec.model];
  if (!sheet) return null;
  const candidates = [spec, { ...spec, light: 'luz' }, { ...spec, incline: 'plano' }, { ...spec, incline: 'plano', light: 'luz' }];
  for (const candidate of candidates) {
    const rect = sheet.frames[frameKey(candidate)];
    if (rect) return { image: sheet.image, rect };
  }
  return null;
}

const defaultFetchJson = async url => {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`No se pudo leer ${url}: ${response.status}`);
  return response.json();
};

const defaultLoadImage = url => new Promise((resolve, reject) => {
  const image = new Image();
  image.decoding = 'async';
  image.onload = () => resolve(image);
  image.onerror = () => reject(new Error(`No se pudo cargar ${url}`));
  image.src = url;
});

export async function loadSpriteAtlas(baseUrl, { fetchJson = defaultFetchJson, loadImage = defaultLoadImage } = {}) {
  const atlas = parseAtlas(await fetchJson(`${baseUrl}/atlas.json`));
  const loaded = await Promise.all(Object.entries(atlas.sheets).map(async ([model, sheet]) =>
    [model, Object.freeze({ ...sheet, image: await loadImage(`${baseUrl}/${sheet.file}`) })]));
  return Object.freeze({ ...atlas, sheets: Object.freeze(Object.fromEntries(loaded)) });
}
