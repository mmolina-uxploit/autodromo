/**
 * Autos elegibles. Libreas tomadas de design/ecosistema.json (verificado por
 * tests/design-coherence.test.js). `performance` ajusta las reglas base solo para el jugador.
 */
export const VEHICLES = Object.freeze([
  {
    id: 'cuna',
    name: 'Cuña',
    model: 'cuna',
    tagline: 'La más rápida en recta. Pide frenar antes de cada curva.',
    performance: { maxSpeedRatio: 1, accelerationTime: 5, steeringRate: 2, centrifugal: 0.3, collisionSpeedRetention: 0.6 },
    liveries: [
      { id: 'lima', name: 'Lima', swatch: '#b6e03a' },
      { id: 'coral', name: 'Coral', swatch: '#ff5a36' }
    ]
  },
  {
    id: 'saeta',
    name: 'Saeta',
    model: 'saeta',
    tagline: 'Sale disparada y dobla firme. Un choque la frena en seco.',
    performance: { maxSpeedRatio: 0.9, accelerationTime: 3.8, steeringRate: 2.3, centrifugal: 0.24, collisionSpeedRetention: 0.5 },
    liveries: [
      { id: 'hormigon', name: 'Hormigón', swatch: '#7f93b0' },
      { id: 'grafito', name: 'Grafito', swatch: '#5f6b78' },
      { id: 'magenta', name: 'Magenta', swatch: '#d8509a' }
    ]
  },
  {
    id: 'bloque',
    name: 'Bloque',
    model: 'bloque',
    tagline: 'Lento y pesado. Pasa entre el tráfico casi sin perder velocidad.',
    performance: { maxSpeedRatio: 0.84, accelerationTime: 5, steeringRate: 1.8, centrifugal: 0.34, collisionSpeedRetention: 0.85 },
    liveries: [
      { id: 'crema', name: 'Crema', swatch: '#e9e2d3' },
      { id: 'turquesa', name: 'Turquesa', swatch: '#3fb3b0' },
      { id: 'mostaza', name: 'Mostaza', swatch: '#e0b54a' }
    ]
  }
].map(v => Object.freeze({ ...v, performance: Object.freeze(v.performance), liveries: Object.freeze(v.liveries.map(Object.freeze)) })));

export const findVehicle = id => VEHICLES.find(v => v.id === id) ?? VEHICLES[0];
export const findLivery = (vehicle, id) => vehicle.liveries.find(l => l.id === id) ?? vehicle.liveries[0];

/** Retrato de tres cuartos generado por design/generador (contrato_sprites.retratos). */
export const portraitUrl = (vehicle, liveryId) => `assets/garage/${vehicle.model}-${liveryId}.png`;
