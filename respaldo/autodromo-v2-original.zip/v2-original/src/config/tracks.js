/**
 * Pistas elegibles. Cada una combina un trazado propio con una zona del ecosistema.
 * Tramo: segmentos de entrada, sostenido y salida, curvatura (positiva = derecha)
 * y desnivel en alturas de segmento. El cierre a altura cero lo agrega Track.fromLayout.
 */
const piece = (enter, hold, leave, curve, hill) => Object.freeze({ enter, hold, leave, curve, hill });

export const TRACKS = Object.freeze([
  {
    id: 'bajo-autopista',
    name: 'Bajo Autopista',
    zone: 'bajo-autopista',
    tagline: 'Equilibrada. Curvas medias y lomas suaves bajo el viaducto.',
    layout: [
      piece(10, 20, 10, 0, 0), piece(25, 50, 25, 4, 20), piece(20, 40, 20, -5, -10),
      piece(10, 30, 10, 0, 30), piece(20, 30, 20, 6, -30), piece(15, 30, 15, -3, 20),
      piece(25, 25, 25, -6, 0), piece(30, 60, 30, 3, -20), piece(20, 40, 20, 0, 15)
    ]
  },
  {
    id: 'costa-rosa',
    name: 'Costa Rosa',
    zone: 'costa-rosa',
    tagline: 'Rápida. Curvas largas junto al mar y casi sin desnivel.',
    layout: [
      piece(10, 20, 10, 0, 0), piece(40, 80, 40, 2, 4), piece(20, 60, 20, 0, -2),
      piece(40, 80, 40, -3, 6), piece(30, 40, 30, 2, -4), piece(20, 80, 20, 0, 2),
      piece(40, 60, 40, -2, -3)
    ]
  },
  {
    id: 'distrito-torre',
    name: 'Distrito Torre',
    zone: 'distrito-torre',
    tagline: 'Técnica. Curvas encadenadas entre torres, sin respiro.',
    layout: [
      piece(8, 12, 8, 0, 0), piece(10, 15, 10, 5, 6), piece(10, 15, 10, -5, -4),
      piece(8, 10, 8, 6, 8), piece(8, 10, 8, -6, -6), piece(12, 20, 12, 4, 10),
      piece(10, 12, 10, -4, -10), piece(8, 10, 8, 6, 4), piece(8, 10, 8, -6, 0),
      piece(10, 15, 10, 3, -6), piece(10, 20, 10, 0, 0), piece(10, 15, 10, -5, 8),
      piece(10, 15, 10, 5, -8)
    ]
  },
  {
    id: 'anillo-neon',
    name: 'Anillo Neón',
    zone: 'anillo-neon',
    tagline: 'Exigente. Lomas altas que esconden curvas cerradas.',
    layout: [
      piece(10, 20, 10, 0, 0), piece(20, 30, 20, 0, 40), piece(15, 25, 15, 6, -30),
      piece(20, 30, 20, 0, 50), piece(15, 20, 15, -6, -40), piece(25, 40, 25, 4, 30),
      piece(15, 25, 15, -5, -50), piece(20, 40, 20, 0, 20)
    ]
  }
].map(track => Object.freeze({ ...track, layout: Object.freeze(track.layout) })));

export const findTrack = id => TRACKS.find(t => t.id === id) ?? TRACKS[0];
