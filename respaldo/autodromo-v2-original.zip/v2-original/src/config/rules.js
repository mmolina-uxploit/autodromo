/**
 * Reglas del juego. Unidades de mundo: la media calzada mide 2000 u y 1 m equivale a 330 u.
 * Los tiempos se expresan en segundos; las velocidades, en unidades por segundo.
 */
const DEFAULT_RULES = {
  segmentLength: 200,
  rumbleLength: 3,
  trackStretch: 3,
  roadHalfWidth: 2000,
  lanes: 3,
  worldUnitsPerMeter: 330,

  maxSpeed: 200 * 60,
  accelerationTime: 5,
  brakingTime: 1,
  coastingTime: 5,
  offRoadDecelerationTime: 2,
  offRoadSpeedLimitRatio: 0.25,
  steeringRate: 2,
  centrifugal: 0.3,
  lateralLimit: 2,

  trafficCount: 140,
  trafficMinSpeedRatio: 0.2,
  trafficSpeedSpreadRatio: 1 / 3,
  trafficSafeStartSegments: 30,

  collisionOverlap: 0.32,
  collisionWindowAhead: 0.6,
  collisionWindowBehind: 0.5,
  collisionSpeedRetention: 0.6,
  collisionPushback: 0.4,

  minLapSeconds: 10,
  countdownSeconds: 3
};

export function createRules(overrides = {}) {
  return Object.freeze({ ...DEFAULT_RULES, ...overrides });
}
