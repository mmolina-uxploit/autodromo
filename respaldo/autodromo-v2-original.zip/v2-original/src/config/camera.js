export const CAMERA = Object.freeze({
  height: 1000,
  fieldOfView: 100,
  drawDistance: 140,
  fogDensity: 5,
  horizonRatio: 0.32,
  unitRatio: 0.62,
  maxPixelRatio: 1.5
});
