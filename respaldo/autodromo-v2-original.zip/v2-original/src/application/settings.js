const isBoolean = value => typeof value === 'boolean';
const pick = (value, allowed) => (allowed.includes(value) ? value : allowed[0]);

const FLAGS = Object.freeze({
  autoThrottle: () => false,
  swapControls: () => false,
  vibration: () => true,
  reducedMotion: catalog => Boolean(catalog.prefersReducedMotion)
});

/**
 * Ajustes del jugador, siempre válidos respecto del catálogo.
 * El color depende del auto: si no le pertenece, se usa el primero del auto.
 * `zone` es el nombre que usaba la versión anterior para la pista.
 */
export function createSettings(input = {}, catalog) {
  const vehicle = pick(input.vehicle, catalog.vehicles);
  const flags = Object.entries(FLAGS).map(([key, fallback]) =>
    [key, isBoolean(input[key]) ? input[key] : fallback(catalog)]);
  return Object.freeze({
    track: pick(input.track ?? input.zone, catalog.tracks),
    vehicle,
    livery: pick(input.livery, catalog.liveries[vehicle]),
    ...Object.fromEntries(flags)
  });
}

function acceptedFields(settings, patch, catalog) {
  const vehicle = catalog.vehicles.includes(patch.vehicle) ? patch.vehicle : settings.vehicle;
  const valid = {
    track: v => catalog.tracks.includes(v),
    vehicle: v => catalog.vehicles.includes(v),
    livery: v => catalog.liveries[vehicle].includes(v),
    ...Object.fromEntries(Object.keys(FLAGS).map(key => [key, isBoolean]))
  };
  return Object.fromEntries(Object.entries(patch).filter(([key, value]) => valid[key]?.(value)));
}

/** Aplica los campos válidos del parche; los inválidos conservan su valor anterior. */
export function updateSettings(settings, patch, catalog) {
  return createSettings({ ...settings, ...acceptedFields(settings, patch, catalog) }, catalog);
}
