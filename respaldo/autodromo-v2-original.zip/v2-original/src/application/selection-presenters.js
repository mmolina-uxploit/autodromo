const clamp01 = v => Math.min(1, Math.max(0, v));
const rating = (value, worst, best) => 1 + Math.round(4 * clamp01((value - worst) / (best - worst)));

/** Escalas de referencia: el extremo izquierdo vale 1 y el derecho 5. */
const SCALES = Object.freeze({
  speed: [0.8, 1.0],
  acceleration: [6, 3.5],
  handling: [1.0, 1.9],
  durability: [0.5, 0.9]
});

/** Cuatro barras de 1 a 5 para la tarjeta de cada auto. */
export function presentVehicleStats(vehicle, rules) {
  const p = {
    maxSpeedRatio: 1,
    accelerationTime: rules.accelerationTime,
    steeringRate: rules.steeringRate,
    centrifugal: rules.centrifugal,
    collisionSpeedRetention: rules.collisionSpeedRetention,
    ...vehicle.performance
  };
  const stat = (id, label, value) => ({ id, label, value, text: `${value} de 5` });
  return [
    stat('speed', 'Velocidad', rating(p.maxSpeedRatio, ...SCALES.speed)),
    stat('acceleration', 'Aceleración', rating(p.accelerationTime, ...SCALES.acceleration)),
    stat('handling', 'Manejo', rating(p.steeringRate * (1 - p.centrifugal), ...SCALES.handling)),
    stat('durability', 'Resistencia', rating(p.collisionSpeedRetention, ...SCALES.durability))
  ];
}

const CURVE_THRESHOLD = 2;
const MAX_CURVE = 6;

/** Resumen de una pista: largo, cantidad de curvas, desnivel y perfil muestreado para graficar. */
export function describeTrack(track, { worldUnitsPerMeter }, samples = 48) {
  let curves = 0;
  let inCurve = false;
  for (let i = 0; i < track.segmentCount; i++) {
    const curving = Math.abs(track.segment(i).curve) >= CURVE_THRESHOLD;
    if (curving && !inCurve) curves++;
    inCurve = curving;
  }

  const step = track.length / samples;
  const heights = Array.from({ length: samples }, (_, i) => track.heightAt(i * step));
  const min = Math.min(...heights);
  const range = Math.max(...heights) - min;
  const meters = track.length / worldUnitsPerMeter;

  return {
    length: `${(meters / 1000).toFixed(2).replace('.', ',')} km`,
    curves,
    elevation: `${Math.round(range / worldUnitsPerMeter)} m`,
    profile: heights.map(h => (range > 0 ? (h - min) / range : 0.5)),
    bends: Array.from({ length: samples }, (_, i) =>
      Math.max(-1, Math.min(1, track.segmentAt(i * step).curve / MAX_CURVE)))
  };
}
