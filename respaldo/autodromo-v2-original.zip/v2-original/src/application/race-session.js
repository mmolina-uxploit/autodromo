import {
  createRace, startCountdown, stepRace, pauseRace, resumeRace, RaceStatus, RaceEvent
} from '../domain/race.js';
import { vehiclePerformance } from '../domain/vehicle.js';
import { toControls } from './controls-mapper.js';
import { SessionEvent } from './race-events.js';

const COLLISION_PULSE_MS = 40;

export const bestLapKey = (trackId, vehicleId) => `${trackId}/${vehicleId}`;

/**
 * Caso de uso principal: ciclo de vida de una carrera con la pista y el auto elegidos.
 * Orquesta el dominio y delega efectos (persistencia, vibración) en puertos.
 */
export function createRaceSession({
  tracks, vehicles, rules, createRng, trafficVariants, bestLapRepository, haptics, getSettings,
  raceFactory = createRace
}) {
  const listeners = new Set();
  let world = worldFor(getSettings());
  let race = newRace();

  function worldFor({ track: wantedTrack, vehicle: wantedVehicle }) {
    const trackId = tracks.has(wantedTrack) ? wantedTrack : tracks.keys().next().value;
    const vehicle = vehicles.find(v => v.id === wantedVehicle) ?? vehicles[0];
    return Object.freeze({
      trackId,
      track: tracks.get(trackId),
      vehicleId: vehicle.id,
      performance: vehiclePerformance(rules, vehicle.performance),
      recordKey: bestLapKey(trackId, vehicle.id)
    });
  }

  function newRace() {
    return raceFactory({
      track: world.track,
      rules,
      rng: createRng(),
      bestLap: bestLapRepository.load(world.recordKey),
      trafficVariants,
      performance: world.performance
    });
  }

  function notify(event) {
    for (const listener of listeners) listener(event);
  }

  function rebuild() {
    const next = worldFor(getSettings());
    const changed = next.recordKey !== world.recordKey;
    world = next;
    race = newRace();
    if (changed) notify({ type: SessionEvent.WORLD_CHANGED, world });
  }

  function apply({ race: next, events }) {
    race = next;
    for (const event of events) {
      if (event.type === RaceEvent.LAP_COMPLETED && event.isBest) bestLapRepository.save(world.recordKey, event.time);
      if (event.type === RaceEvent.COLLISION && getSettings().vibration) haptics.pulse(COLLISION_PULSE_MS);
      notify(event);
    }
    return events;
  }

  return {
    get state() { return race; },
    get world() { return world; },
    bestLapFor: (trackId, vehicleId) => bestLapRepository.load(bestLapKey(trackId, vehicleId)),

    /** Aplica una selección nueva solo mientras la carrera espera la largada. */
    syncSelection() {
      if (race.status !== RaceStatus.READY) return;
      if (worldFor(getSettings()).recordKey === world.recordKey) return;
      rebuild();
    },

    start() { apply(startCountdown(race)); },
    restart() { rebuild(); apply(startCountdown(race)); },
    reset() { rebuild(); },
    pause() { apply(pauseRace(race)); },
    resume() { apply(resumeRace(race)); },
    togglePause() {
      apply(race.status === RaceStatus.PAUSED ? resumeRace(race) : pauseRace(race));
    },
    tick(dt, actions) {
      const controls = toControls(actions, getSettings());
      const events = apply(stepRace(race, controls, dt, { track: world.track, rules }));
      return { state: race, events, controls };
    },
    subscribe(listener) {
      listeners.add(listener);
      return () => listeners.delete(listener);
    }
  };
}
