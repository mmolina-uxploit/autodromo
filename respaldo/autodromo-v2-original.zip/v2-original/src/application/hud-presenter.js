import { RaceEvent } from '../domain/race.js';

export const TOP_SPEED_KMH = 230;

export function formatLapTime(seconds) {
  if (seconds === null || seconds === undefined) return null;
  const centis = Math.round(seconds * 100);
  const minutes = Math.floor(centis / 6000);
  const rest = (centis - minutes * 6000) / 100;
  return `${minutes}:${rest.toFixed(2).padStart(5, '0')}`;
}

export const toKmh = (speed, maxSpeed) => Math.round((speed / maxSpeed) * TOP_SPEED_KMH);

export function presentHud(race, rules) {
  return {
    speed: String(toKmh(race.player.speed, rules.maxSpeed)),
    lap: `Vuelta ${race.timer.lap}`,
    time: formatLapTime(race.timer.current),
    best: formatLapTime(race.timer.best) ?? 'sin registro'
  };
}

/** Texto breve para la región en vivo; null si el evento no se anuncia. */
export function describeEvent(event) {
  switch (event.type) {
    case RaceEvent.COUNTDOWN_TICK: return String(event.value);
    case RaceEvent.STARTED: return 'Largada';
    case RaceEvent.LAP_COMPLETED:
      return `Vuelta ${event.lap} en ${formatLapTime(event.time)}.${event.isBest ? ' Mejor vuelta.' : ''}`;
    case RaceEvent.COLLISION: return 'Choque';
    case RaceEvent.PAUSED: return 'Pausa';
    case RaceEvent.RESUMED: return 'Carrera reanudada';
    default: return null;
  }
}
