const positive = v => Number.isFinite(v) && v > 0;

/** Atributos que un auto puede ajustar y la condición que debe cumplir cada uno. */
const TUNABLE = Object.freeze({
  maxSpeedRatio: v => positive(v) && v <= 1.5,
  accelerationTime: positive,
  brakingTime: positive,
  offRoadDecelerationTime: positive,
  steeringRate: positive,
  centrifugal: v => Number.isFinite(v) && v >= 0,
  collisionSpeedRetention: v => positive(v) && v < 1
});

/**
 * Reglas de manejo del jugador para un auto: las reglas base con los ajustes del auto aplicados.
 * El tráfico sigue usando las reglas base.
 */
export function vehiclePerformance(rules, tuning = {}) {
  const accepted = {};
  for (const [key, valid] of Object.entries(TUNABLE)) {
    if (!(key in tuning)) continue;
    if (!valid(tuning[key])) throw new RangeError(`Valor inválido para ${key}: ${tuning[key]}`);
    accepted[key] = tuning[key];
  }
  const { maxSpeedRatio = 1, ...direct } = accepted;
  return Object.freeze({ ...rules, ...direct, maxSpeed: rules.maxSpeed * maxSpeedRatio });
}
