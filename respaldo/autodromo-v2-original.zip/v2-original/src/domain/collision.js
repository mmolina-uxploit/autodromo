import { signedWrap, wrap } from './math.js';

/** Devuelve el primer auto más lento que el jugador alcanza en su carril, o null. */
export function findCollision(player, cars, trackLength, rules) {
  const ahead = rules.segmentLength * rules.collisionWindowAhead;
  const behind = rules.segmentLength * rules.collisionWindowBehind;
  for (const car of cars) {
    if (player.speed <= car.speed) continue;
    if (Math.abs(player.x - car.x) >= rules.collisionOverlap) continue;
    const gap = signedWrap(car.z - player.z, trackLength);
    if (gap > -behind && gap < ahead) return car;
  }
  return null;
}

/** El jugador queda detrás del auto, con una fracción de la velocidad de ese auto. */
export function resolveCollision(player, car, trackLength, rules) {
  return Object.freeze({
    ...player,
    speed: car.speed * rules.collisionSpeedRetention,
    z: wrap(car.z - rules.segmentLength * rules.collisionPushback, trackLength)
  });
}
