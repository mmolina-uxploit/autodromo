import { createPlayer, stepPlayerPhysics } from './player.js';
import { createTraffic, advanceTraffic } from './traffic.js';
import { findCollision, resolveCollision } from './collision.js';
import { createLapTimer, tickLapTimer, completeLap } from './lap-timer.js';
import { vehiclePerformance } from './vehicle.js';

export const RaceStatus = Object.freeze({
  READY: 'ready',
  COUNTDOWN: 'countdown',
  RUNNING: 'running',
  PAUSED: 'paused'
});

export const RaceEvent = Object.freeze({
  COUNTDOWN_TICK: 'countdown-tick',
  STARTED: 'started',
  LAP_COMPLETED: 'lap-completed',
  COLLISION: 'collision',
  PAUSED: 'paused',
  RESUMED: 'resumed'
});

export const IMPACT_SECONDS = 0.35;

const unchanged = race => ({ race, events: [] });

export function createRace({ track, rules, rng, bestLap = null, trafficVariants = 1, performance = vehiclePerformance(rules) }) {
  return Object.freeze({
    performance,
    status: RaceStatus.READY,
    countdownTotal: rules.countdownSeconds,
    countdown: rules.countdownSeconds,
    resumeStatus: null,
    player: createPlayer(),
    traffic: Object.freeze(createTraffic(track, rules, rng, trafficVariants)),
    timer: createLapTimer(bestLap),
    impact: 0
  });
}

export function startCountdown(race) {
  if (race.status !== RaceStatus.READY) return unchanged(race);
  return {
    race: Object.freeze({ ...race, status: RaceStatus.COUNTDOWN, countdown: race.countdownTotal }),
    events: [{ type: RaceEvent.COUNTDOWN_TICK, value: Math.ceil(race.countdownTotal) }]
  };
}

export function pauseRace(race) {
  if (race.status !== RaceStatus.RUNNING && race.status !== RaceStatus.COUNTDOWN) return unchanged(race);
  return {
    race: Object.freeze({ ...race, status: RaceStatus.PAUSED, resumeStatus: race.status }),
    events: [{ type: RaceEvent.PAUSED }]
  };
}

export function resumeRace(race) {
  if (race.status !== RaceStatus.PAUSED) return unchanged(race);
  return {
    race: Object.freeze({ ...race, status: race.resumeStatus, resumeStatus: null }),
    events: [{ type: RaceEvent.RESUMED }]
  };
}

/** Avanza la carrera dt segundos. Puro: no muta el estado recibido. */
export function stepRace(race, controls, dt, world) {
  if (race.status === RaceStatus.COUNTDOWN) return stepCountdown(race, dt);
  if (race.status === RaceStatus.RUNNING) return stepRunning(race, controls, dt, world);
  return unchanged(race);
}

function stepCountdown(race, dt) {
  const remaining = race.countdown - dt;
  if (remaining <= 0) {
    return {
      race: Object.freeze({ ...race, status: RaceStatus.RUNNING, countdown: 0 }),
      events: [{ type: RaceEvent.STARTED }]
    };
  }
  const events = Math.ceil(remaining) < Math.ceil(race.countdown)
    ? [{ type: RaceEvent.COUNTDOWN_TICK, value: Math.ceil(remaining) }]
    : [];
  return { race: Object.freeze({ ...race, countdown: remaining }), events };
}

function stepRunning(race, controls, dt, { track, rules }) {
  const events = [];
  const handling = race.performance;
  const curve = track.segmentAt(race.player.z).curve;
  let player = stepPlayerPhysics(race.player, controls, curve, dt, handling);

  const travelled = player.z + player.speed * dt;
  player = Object.freeze({ ...player, z: track.wrap(travelled) });

  let timer = tickLapTimer(race.timer, dt);
  if (travelled >= track.length) {
    const lap = completeLap(timer, rules.minLapSeconds);
    timer = lap.timer;
    if (lap.completed) events.push({ type: RaceEvent.LAP_COMPLETED, ...lap.completed });
  }

  const traffic = Object.freeze(advanceTraffic(race.traffic, dt, track.length));
  let impact = Math.max(0, race.impact - dt);
  const hit = findCollision(player, traffic, track.length, handling);
  if (hit) {
    const before = player.speed;
    player = resolveCollision(player, hit, track.length, handling);
    impact = IMPACT_SECONDS;
    events.push({ type: RaceEvent.COLLISION, speedLost: before - player.speed });
  }

  return { race: Object.freeze({ ...race, player, traffic, timer, impact }), events };
}
