import { clamp } from './math.js';

/** x: desplazamiento lateral en medias calzadas; z: distancia recorrida en el circuito. */
export function createPlayer(overrides = {}) {
  return Object.freeze({ x: 0, z: 0, speed: 0, ...overrides });
}

export const isOffRoad = player => Math.abs(player.x) > 1;

/** Integra dirección, fuerza centrífuga y velocidad. No mueve al auto a lo largo del circuito. */
export function stepPlayerPhysics(player, controls, curve, dt, rules) {
  const speedRatio = player.speed / rules.maxSpeed;
  const lateralStep = dt * rules.steeringRate * speedRatio;
  const x = player.x
    + controls.steer * lateralStep
    - lateralStep * speedRatio * curve * rules.centrifugal;

  let speed = player.speed + longitudinalAcceleration(controls, rules) * dt;
  const offRoadLimit = rules.maxSpeed * rules.offRoadSpeedLimitRatio;
  if (isOffRoad({ x }) && speed > offRoadLimit) {
    speed -= (rules.maxSpeed / rules.offRoadDecelerationTime) * dt;
  }

  return Object.freeze({
    ...player,
    x: clamp(x, -rules.lateralLimit, rules.lateralLimit),
    speed: clamp(speed, 0, rules.maxSpeed)
  });
}

function longitudinalAcceleration({ throttle, brake }, rules) {
  if (brake > 0) return -(rules.maxSpeed / rules.brakingTime) * brake;
  if (throttle > 0) return (rules.maxSpeed / rules.accelerationTime) * throttle;
  return -(rules.maxSpeed / rules.coastingTime);
}
