import { wrap } from './math.js';

/** Centros de carril en medias calzadas, de izquierda a derecha. */
export function laneCenters(lanes) {
  const width = 2 / lanes;
  return Array.from({ length: lanes }, (_, i) => -1 + width * (i + 0.5));
}

export function createTraffic(track, rules, rng, variantCount) {
  const centers = laneCenters(rules.lanes);
  const safeStart = rules.trafficSafeStartSegments * track.segmentLength;
  const span = track.length - safeStart;
  return Array.from({ length: rules.trafficCount }, (_, id) => Object.freeze({
    id,
    z: safeStart + rng() * span,
    x: centers[Math.floor(rng() * centers.length)],
    speed: rules.maxSpeed * (rules.trafficMinSpeedRatio + rng() * rules.trafficSpeedSpreadRatio),
    variant: Math.floor(rng() * variantCount)
  }));
}

export function advanceTraffic(cars, dt, trackLength) {
  return cars.map(car => Object.freeze({ ...car, z: wrap(car.z + car.speed * dt, trackLength) }));
}
