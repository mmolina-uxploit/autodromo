export const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
export const lerp = (a, b, t) => a + (b - a) * t;
export const easeIn = (a, b, t) => a + (b - a) * t * t;
export const easeInOut = (a, b, t) => a + (b - a) * (-Math.cos(t * Math.PI) / 2 + 0.5);
export const wrap = (value, length) => ((value % length) + length) % length;

/** Distancia con signo por el camino más corto en un circuito de largo dado. */
export function signedWrap(delta, length) {
  const d = wrap(delta, length);
  return d > length / 2 ? d - length : d;
}
