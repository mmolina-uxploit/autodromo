import { easeIn, easeInOut, lerp, wrap } from './math.js';

const CLOSING_PIECE = Object.freeze({ enter: 25, hold: 25, leave: 25, curve: 0 });

/** Circuito cerrado formado por segmentos inmutables. */
export class Track {
  #segments;
  #segmentLength;

  constructor(segments, segmentLength) {
    this.#segments = Object.freeze([...segments]);
    this.#segmentLength = segmentLength;
    Object.freeze(this);
  }

  static fromLayout(layout, { segmentLength, rumbleLength, trackStretch = 1 }) {
    const builder = new TrackBuilder(segmentLength, rumbleLength);
    for (const piece of layout) builder.addPiece(stretch(piece, trackStretch));
    builder.closeLoop(trackStretch);
    return new Track(builder.segments, segmentLength);
  }

  get segmentLength() { return this.#segmentLength; }
  get segmentCount() { return this.#segments.length; }
  get length() { return this.#segments.length * this.#segmentLength; }

  wrap(z) { return wrap(z, this.length); }
  segment(index) { return this.#segments[wrap(index, this.#segments.length)]; }
  indexAt(z) { return Math.floor(this.wrap(z) / this.#segmentLength); }
  segmentAt(z) { return this.#segments[this.indexAt(z)]; }

  heightAt(z) {
    const s = this.segmentAt(z);
    const t = (this.wrap(z) % this.#segmentLength) / this.#segmentLength;
    return lerp(s.startHeight, s.endHeight, t);
  }
}

class TrackBuilder {
  #list = [];
  #segmentLength;
  #rumbleLength;

  constructor(segmentLength, rumbleLength) {
    this.#segmentLength = segmentLength;
    this.#rumbleLength = rumbleLength;
  }

  get segments() { return this.#list; }

  addPiece({ enter, hold, leave, curve, hill }) {
    const total = enter + hold + leave;
    if (!(total > 0)) throw new RangeError('Cada tramo necesita al menos un segmento.');
    const from = this.#lastHeight();
    const to = from + hill * this.#segmentLength;
    const height = n => easeInOut(from, to, n / total);
    for (let n = 0; n < enter; n++) this.#addSegment(easeIn(0, curve, n / enter), height(n));
    for (let n = 0; n < hold; n++) this.#addSegment(curve, height(enter + n));
    for (let n = 0; n < leave; n++) this.#addSegment(easeInOut(curve, 0, n / leave), height(enter + hold + n));
  }

  closeLoop(trackStretch) {
    const hill = -this.#lastHeight() / this.#segmentLength;
    this.addPiece(stretch({ ...CLOSING_PIECE, hill }, trackStretch));
    this.#addSegment(0, 0);
  }

  #lastHeight() {
    return this.#list.length ? this.#list[this.#list.length - 1].endHeight : 0;
  }

  #addSegment(curve, endHeight) {
    const index = this.#list.length;
    this.#list.push(Object.freeze({
      index,
      curve,
      startHeight: this.#lastHeight(),
      endHeight,
      band: Math.floor(index / this.#rumbleLength) % 2,
      isStartLine: index < this.#rumbleLength
    }));
  }
}

function stretch(piece, factor) {
  return { ...piece, enter: piece.enter * factor, hold: piece.hold * factor, leave: piece.leave * factor };
}
