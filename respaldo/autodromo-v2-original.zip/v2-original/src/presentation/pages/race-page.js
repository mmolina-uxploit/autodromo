import { RaceEvent, RaceStatus } from '../../application/race-events.js';
import { presentHud, describeEvent, formatLapTime } from '../../application/hud-presenter.js';
import { presentVehicleStats } from '../../application/selection-presenters.js';
import { findVehicle, findLivery, portraitUrl } from '../../config/vehicles.js';
import { RaceLayout } from '../templates/race-layout.js';
import { Hud } from '../organisms/hud.js';
import { TouchControls } from '../organisms/touch-controls.js';
import { StartMenu } from '../organisms/start-menu.js';
import { CarSelect } from '../organisms/car-select.js';
import { TrackSelect, trackVisual } from '../organisms/track-select.js';
import { PauseMenu } from '../organisms/pause-menu.js';
import { SettingsPanel } from '../organisms/settings-panel.js';
import { HelpPanel } from '../organisms/help-panel.js';
import { Toast } from '../molecules/toast.js';
import { Countdown } from '../molecules/countdown.js';
import { LiveRegion } from '../atoms/live-region.js';
import { createDialogStack } from '../dialog-stack.js';

const RACING = [RaceStatus.RUNNING, RaceStatus.COUNTDOWN];

/**
 * Página de carrera: compone organismos y traduce eventos de la sesión en interfaz.
 * `tracks` llega con zona y resumen ya resueltos desde la raíz de composición.
 */
export function createRacePage({ root, canvas, session, settingsStore, rules, vehicles, tracks, actions, bindHold }) {
  const layout = RaceLayout({ canvas });
  const hud = Hud({ onPause: requestPause });
  const touch = TouchControls({
    bindHold,
    onAction: (action, pressed) => (pressed ? actions.press(action, 'touch') : actions.release(action, 'touch'))
  });
  const toast = Toast();
  const countdown = Countdown();
  const live = LiveRegion();

  const startMenu = StartMenu({
    onChooseCar: () => openSelector(carSelect),
    onChooseTrack: () => openSelector(trackSelect),
    onStart: startRace,
    onSettings: openSettings,
    onHelp: openHelp
  });
  const carSelect = CarSelect({
    vehicles: vehicles.map(v => ({ ...v, stats: presentVehicleStats(v, rules) })),
    settings: settingsStore.current,
    onVehicle: vehicle => settingsStore.update({ vehicle }),
    onLivery: livery => settingsStore.update({ livery }),
    onDone: back
  });
  const trackSelect = TrackSelect({
    tracks,
    settings: settingsStore.current,
    onTrack: track => settingsStore.update({ track }),
    onDone: back
  });
  const pauseMenu = PauseMenu({ onResume: resume, onRestart: restart, onSettings: openSettings, onHelp: openHelp, onExit: exitToMenu });
  const settingsPanel = SettingsPanel({ settings: settingsStore.current, onChange: patch => settingsStore.update(patch), onDone: back });
  const helpPanel = HelpPanel({ onDone: back });

  layout.slots.hud.append(hud.el);
  layout.slots.overlay.append(countdown.el, toast.el);
  layout.slots.controls.append(touch.el);
  layout.slots.live.append(live.el);
  root.replaceChildren(layout.el);

  const dialogs = createDialogStack({
    host: layout.slots.dialogs,
    onEmpty: () => layout.stage.focus({ preventScroll: true })
  });

  function isRacing() { return RACING.includes(session.state.status); }
  function back() { dialogs.back(); }

  function startRace() {
    dialogs.closeAll();
    actions.releaseAll();
    session.start();
  }

  function requestPause() {
    if (!isRacing()) return;
    actions.releaseAll();
    session.pause();
    dialogs.open(pauseMenu, { onCancel: resume });
  }

  function resume() {
    dialogs.closeAll();
    session.resume();
  }

  function restart() {
    dialogs.closeAll();
    actions.releaseAll();
    countdown.hide();
    session.restart();
  }

  function exitToMenu() {
    session.reset();
    countdown.hide();
    dialogs.closeAll();
    refreshSelection(settingsStore.current);
    dialogs.open(startMenu);
  }

  function openSelector(selector) {
    selector.setValues(settingsStore.current);
    dialogs.open(selector, { onCancel: back });
  }

  function openSettings() {
    settingsPanel.setValues(settingsStore.current);
    dialogs.open(settingsPanel, { onCancel: back });
  }

  function openHelp() {
    dialogs.open(helpPanel, { onCancel: back });
  }

  function refreshSelection(settings) {
    const vehicle = findVehicle(settings.vehicle);
    const livery = findLivery(vehicle, settings.livery);
    const trackItem = tracks.find(t => t.id === settings.track) ?? tracks[0];
    const best = formatLapTime(session.bestLapFor(trackItem.id, vehicle.id));
    startMenu.update({
      vehicle,
      livery,
      portrait: portraitUrl(vehicle, livery.id),
      trackItem,
      trackVisual: trackVisual(trackItem),
      bestText: best ? `Mejor vuelta con esta combinación: ${best}` : 'Todavía no hay vueltas con esta combinación.'
    });
    trackSelect.setBestLaps(trackId => {
      const time = formatLapTime(session.bestLapFor(trackId, vehicle.id));
      return time ? `Mejor con ${vehicle.name}: ${time}` : `Sin vueltas con ${vehicle.name}`;
    });
  }

  function onRaceEvent(event) {
    const announcement = describeEvent(event);
    if (announcement) live.announce(announcement);
    if (event.type === RaceEvent.COUNTDOWN_TICK) countdown.show(String(event.value));
    if (event.type === RaceEvent.STARTED) countdown.show('¡Ya!', 700);
    if (event.type === RaceEvent.LAP_COMPLETED) {
      toast.show(`${event.isBest ? 'Mejor vuelta' : `Vuelta ${event.lap}`} ${formatLapTime(event.time)}`);
      refreshSelection(settingsStore.current);
    }
  }

  function applySettings(settings) {
    touch.setSwapped(settings.swapControls);
    touch.setAutoThrottle(settings.autoThrottle);
    document.documentElement.classList.toggle('is-reduced-motion', settings.reducedMotion);
    carSelect.setValues(settings);
    trackSelect.setValues(settings);
    settingsPanel.setValues(settings);
    refreshSelection(settings);
  }

  session.subscribe(onRaceEvent);
  settingsStore.subscribe(applySettings);
  applySettings(settingsStore.current);
  document.addEventListener('visibilitychange', () => { if (document.hidden) requestPause(); });

  dialogs.open(startMenu);

  return {
    onFrame(result) { hud.update(presentHud(result.state, rules)); },
    requestPause,
    isGameActive: () => !dialogs.isOpen
  };
}
