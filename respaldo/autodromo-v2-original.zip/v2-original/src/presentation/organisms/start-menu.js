import { h } from '../dom.js';
import { DialogPanel } from './dialog-panel.js';
import { SummaryTile } from '../molecules/summary-tile.js';
import { Picture } from '../atoms/picture.js';
import { Button } from '../atoms/button.js';
import { Text } from '../atoms/typography.js';

/** Inicio: muestra la combinación actual de auto y pista y permite largar en un toque. */
export function StartMenu({ onChooseCar, onChooseTrack, onStart, onSettings, onHelp }) {
  const car = SummaryTile({ caption: 'Auto', action: 'Cambiar', onPress: onChooseCar });
  const track = SummaryTile({ caption: 'Pista', action: 'Cambiar', onPress: onChooseTrack });
  const best = Text({ tone: 'muted' });
  const start = Button({ label: 'Largar', variant: 'primary', icon: 'play', onPress: onStart });

  return {
    el: DialogPanel({
      title: 'Autódromo',
      className: 'o-start',
      body: [Text({ text: 'Elegí auto y pista, o largá con la combinación de la última vez.' }), h('div', { class: 'o-start__picks' }, car.el, track.el), best],
      footer: [start, Button({ label: 'Ajustes', icon: 'sliders', onPress: onSettings }), Button({ label: 'Controles', icon: 'help', onPress: onHelp })]
    }),
    initialFocus: start,
    update({ vehicle, livery, portrait, trackItem, trackVisual, bestText }) {
      car.update({ name: vehicle.name, info: livery.name, visual: Picture({ src: portrait, width: 560, height: 300 }) });
      track.update({ name: trackItem.name, info: `${trackItem.zone.time === 'noche' ? 'De noche' : 'De día'}, ${trackItem.info.length}`, visual: trackVisual });
      best.textContent = bestText;
    }
  };
}
