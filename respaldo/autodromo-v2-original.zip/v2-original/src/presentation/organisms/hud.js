import { h } from '../dom.js';
import { Stat } from '../molecules/stat.js';
import { Readout } from '../atoms/readout.js';
import { Button } from '../atoms/button.js';

export function Hud({ onPause }) {
  const speed = Stat({ label: 'km/h', size: 'xl', initial: '0' });
  const time = Stat({ label: 'Vuelta 1', size: 'l', align: 'end', initial: '0:00.00' });
  const best = Readout({ size: 'caption', initial: 'Mejor: sin registro' });
  const pause = Button({
    label: 'Pausa', icon: 'pause', iconOnly: true, variant: 'plate',
    onPress: onPause, 'aria-keyshortcuts': 'Escape P'
  });

  return {
    el: h('section', { class: 'o-hud', 'aria-label': 'Tablero de carrera' },
      h('div', { class: 'o-hud__plate' }, speed.el),
      h('div', { class: 'o-hud__group' }, h('div', { class: 'o-hud__plate o-hud__plate--end' }, time.el, best.el), pause)),
    update(model) {
      speed.setValue(model.speed);
      time.setValue(model.time);
      time.setCaption(model.lap);
      best.set(`Mejor: ${model.best}`);
    }
  };
}
