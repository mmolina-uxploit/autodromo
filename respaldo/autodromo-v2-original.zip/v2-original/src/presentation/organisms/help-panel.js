import { h } from '../dom.js';
import { DialogPanel } from './dialog-panel.js';
import { KeyList } from '../molecules/key-list.js';
import { Button } from '../atoms/button.js';
import { Heading, Text } from '../atoms/typography.js';

export function HelpPanel({ onDone }) {
  const back = Button({ label: 'Volver', variant: 'primary', onPress: onDone });
  return {
    el: DialogPanel({
      title: 'Controles',
      className: 'o-help',
      body: [
        h('section', { class: 'o-help__section' },
          Heading({ level: 3, text: 'Teclado' }),
          KeyList([
            { keys: ['←', '→'], description: 'Dirigir. También A y D.' },
            { keys: ['↑'], description: 'Acelerar. También W.' },
            { keys: ['↓', 'Espacio'], description: 'Frenar. También S.' },
            { keys: ['Esc', 'P'], description: 'Pausar y abrir el menú.' },
            { keys: ['Tab'], description: 'Moverse entre opciones de los menús.' }
          ])),
        h('section', { class: 'o-help__section' },
          Heading({ level: 3, text: 'Pantalla táctil' }),
          Text({ text: 'Mantené presionados los botones: dirección abajo a la izquierda, freno y acelerador abajo a la derecha. Podés usar varios dedos a la vez e invertir los lados en Ajustes.' }))
      ],
      footer: [back]
    }),
    initialFocus: back
  };
}
