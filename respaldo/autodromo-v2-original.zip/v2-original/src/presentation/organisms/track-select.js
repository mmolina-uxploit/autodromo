import { h } from '../dom.js';
import { DialogPanel } from './dialog-panel.js';
import { OptionCard } from '../molecules/option-card.js';
import { FactList } from '../molecules/fact-list.js';
import { ProfileGraphic } from '../atoms/profile-graphic.js';
import { Button } from '../atoms/button.js';

export const trackVisual = track => ProfileGraphic({
  profile: track.info.profile,
  bends: track.info.bends,
  sky: track.zone.sky,
  ground: track.zone.road.ground[0],
  accent: track.zone.accent
});

/** Selección de pista: perfil de altura, datos clave y mejor vuelta con el auto elegido. */
export function TrackSelect({ tracks, settings, onTrack, onDone }) {
  const cards = tracks.map(track => {
    const best = h('span', { class: 'o-track-select__best' });
    const card = OptionCard({
      name: 'pista',
      value: track.id,
      checked: track.id === settings.track,
      title: track.name,
      description: track.tagline,
      media: trackVisual(track),
      extra: [
        FactList([track.info.length, `${track.info.curves} curvas`, `Desnivel ${track.info.elevation}`, track.zone.time === 'noche' ? 'De noche' : 'De día']),
        best
      ]
    });
    return { track, best, ...card };
  });

  const group = h('fieldset', { class: 'o-track-select__cards' },
    h('legend', { class: 'u-visually-hidden', text: 'Pistas disponibles' }),
    cards.map(c => c.el));
  group.addEventListener('change', event => { if (event.target.name === 'pista') onTrack(event.target.value); });

  const done = Button({ label: 'Listo', variant: 'primary', icon: 'check', onPress: onDone });

  return {
    el: DialogPanel({ title: 'Elegí pista', className: 'o-select o-track-select', body: [group], footer: [done] }),
    get initialFocus() { return cards.find(c => c.input.checked)?.input ?? done; },
    setValues(next) { for (const card of cards) card.input.checked = card.track.id === next.track; },
    /** bestText(trackId) → texto de la mejor vuelta con el auto elegido. */
    setBestLaps(bestText) { for (const card of cards) card.best.textContent = bestText(card.track.id); }
  };
}
