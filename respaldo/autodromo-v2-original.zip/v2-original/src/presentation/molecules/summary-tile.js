import { h } from '../dom.js';
import { Icon } from '../atoms/icon.js';

/** Resumen de una elección con acceso directo a cambiarla. Todo el bloque es un botón. */
export function SummaryTile({ caption, action, onPress }) {
  const media = h('span', { class: 'm-summary__media', 'aria-hidden': 'true' });
  const title = h('span', { class: 'm-summary__title' });
  const detail = h('span', { class: 'm-summary__detail' });
  const el = h('button', { type: 'button', class: 'm-summary', onClick: onPress },
    media,
    h('span', { class: 'm-summary__text' },
      h('span', { class: 'm-summary__caption', text: caption }), title, detail),
    h('span', { class: 'm-summary__action', 'aria-hidden': 'true' }, Icon('right', { size: 28 })));

  return {
    el,
    update({ name, info, visual }) {
      title.textContent = name;
      detail.textContent = info;
      media.replaceChildren(visual);
      el.setAttribute('aria-label', `${action} ${caption.toLowerCase()}. Ahora: ${name}, ${info}.`);
    }
  };
}
