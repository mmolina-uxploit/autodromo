# Ecosistema visual de Autódromo

La coherencia vive en tres cosas: una geometría por modelo, una luz fija y una tinta. Todo lo demás se deriva.

## Estructura

| Archivo | Qué es |
|---|---|
| `referencias-estilo.json` | Estilo extraído de cada referencia (R1 a R8): técnica, línea, paleta con roles, luz, composición, formas y aporte al sistema. |
| `ecosistema.json` | Fuente única: patrones, decisiones, paleta, reglas, zonas de pista, vehículos con libreas y contrato de sprites. |
| `generador/generar_sprites.py` | Construye los tres autos en 3D facetado y los dibuja con sombreado de tres bandas y tinta. Lee todo color y parámetro de `ecosistema.json`. |
| `../assets/sprites/*.png` + `atlas.json` | Hojas de sprites que usa el juego, con coordenadas y ancla de cada cuadro. El generador escribe ahí directamente. |
| `hojas-modelo/*.png` | Vistas canónicas de cada auto (lateral, frente, trasera, planta, tres cuartos) y capturas por librea. |
| `tablero-ecosistema.png` | Paleta, cuatro zonas de pista y el parque de autos en una sola lámina. |

## Hojas de sprites

Columnas: siete giros, de −21° a +21°. Positivo significa trompa a la derecha.
Filas: librea × inclinación (`plano`, `subida`) × estado de luz (`luz`, `freno`; el freno solo existe para la Cuña).
Todos los cuadros miden lo mismo y comparten el ancla, que es el punto del piso bajo el centro del auto.

Nombre de cada cuadro: `{modelo}_{librea}_{inclinacion}_{luz|freno}_g{indice_giro}`, por ejemplo `cuna_lima_plano_freno_g3`.

## Regenerar

```bash
pip install numpy scipy pillow
npm run sprites
```

Etapas sueltas: `npm run sprites -- sprites --modelos saeta`, `retratos`, `hojas` o `tablero`. El atlas se fusiona con lo ya generado, así que regenerar un modelo no borra los otros.

Para una librea nueva, agregala en `ecosistema.json` → `vehiculos.{modelo}.libreas` y regenerá. Para otro ángulo, editá `contrato_sprites.giros_grados`. Las hojas no se retocan a mano: cualquier cambio entra por el JSON o por la geometría del generador.
