import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createRules } from '../../src/config/rules.js';
import { vehiclePerformance } from '../../src/domain/vehicle.js';

const rules = createRules();

test('sin ajustes, el rendimiento es el de las reglas base', () => {
  const p = vehiclePerformance(rules, {});
  assert.equal(p.maxSpeed, rules.maxSpeed);
  assert.equal(p.accelerationTime, rules.accelerationTime);
  assert.equal(p.collisionSpeedRetention, rules.collisionSpeedRetention);
});

test('maxSpeedRatio escala la velocidad máxima', () => {
  assert.equal(vehiclePerformance(rules, { maxSpeedRatio: 0.5 }).maxSpeed, rules.maxSpeed / 2);
});

test('solo acepta atributos de manejo; ignora el resto', () => {
  const p = vehiclePerformance(rules, { steeringRate: 3, trafficCount: 0, minLapSeconds: 1 });
  assert.equal(p.steeringRate, 3);
  assert.equal(p.trafficCount, rules.trafficCount);
  assert.equal(p.minLapSeconds, rules.minLapSeconds);
});

test('rechaza valores fuera de rango', () => {
  assert.throws(() => vehiclePerformance(rules, { accelerationTime: 0 }), RangeError);
  assert.throws(() => vehiclePerformance(rules, { maxSpeedRatio: -1 }), RangeError);
  assert.throws(() => vehiclePerformance(rules, { collisionSpeedRetention: 1 }), RangeError);
  assert.throws(() => vehiclePerformance(rules, { centrifugal: Number.NaN }), RangeError);
});

test('el rendimiento es inmutable', () => {
  assert.ok(Object.isFrozen(vehiclePerformance(rules, {})));
});
