import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  createRace, startCountdown, stepRace, pauseRace, resumeRace, RaceStatus, RaceEvent
} from '../../src/domain/race.js';
import { createControls } from '../../src/domain/controls.js';
import { createPlayer } from '../../src/domain/player.js';
import { createRng } from '../../src/domain/rng.js';
import { smallWorld } from '../helpers.js';

const gas = createControls({ throttle: 1 });

function setup() {
  const world = smallWorld({ countdownSeconds: 3 });
  const race = createRace({ ...world, rng: createRng(1) });
  return { ...world, race };
}
const running = (race, patch = {}) => ({ ...race, status: RaceStatus.RUNNING, ...patch });

test('una carrera nueva espera la largada sin moverse', () => {
  const { race, track, rules } = setup();
  const { race: after, events } = stepRace(race, gas, 1, { track, rules });
  assert.equal(after.status, RaceStatus.READY);
  assert.equal(after.player.z, 0);
  assert.deepEqual(events, []);
});

test('la cuenta regresiva anuncia 3, 2, 1 y larga', () => {
  const { race, track, rules } = setup();
  const seen = [];
  let r = startCountdown(race);
  seen.push(...r.events);
  for (let i = 0; i < 3; i++) {
    r = stepRace(r.race, gas, 1, { track, rules });
    seen.push(...r.events);
  }
  assert.deepEqual(seen.map(e => e.value ?? e.type), [3, 2, 1, RaceEvent.STARTED]);
  assert.equal(r.race.status, RaceStatus.RUNNING);
});

test('durante la cuenta regresiva el auto no avanza', () => {
  const { race, track, rules } = setup();
  const { race: after } = stepRace(startCountdown(race).race, gas, 0.5, { track, rules });
  assert.equal(after.player.z, 0);
});

test('en carrera el auto avanza y el reloj corre', () => {
  const { race, track, rules } = setup();
  const { race: after } = stepRace(running(race, { player: createPlayer({ speed: 1000 }) }), gas, 0.1, { track, rules });
  assert.ok(after.player.z > 0);
  assert.ok(Math.abs(after.timer.current - 0.1) < 1e-12);
});

test('cruzar la meta completa la vuelta', () => {
  const { race, track, rules } = setup();
  const start = running(race, {
    player: createPlayer({ z: track.length - 10, speed: 1000 }),
    timer: { ...race.timer, current: 30 }
  });
  const { race: after, events } = stepRace(start, createControls(), 0.1, { track, rules });
  const lap = events.find(e => e.type === RaceEvent.LAP_COMPLETED);
  assert.equal(lap.lap, 1);
  assert.equal(after.timer.lap, 2);
  assert.ok(after.player.z < 200);
});

test('la pausa congela el mundo y se reanuda en el mismo estado', () => {
  const { race, track, rules } = setup();
  const live = running(race, { player: createPlayer({ speed: 1000 }) });
  const paused = pauseRace(live);
  assert.equal(paused.race.status, RaceStatus.PAUSED);
  assert.deepEqual(paused.events.map(e => e.type), [RaceEvent.PAUSED]);
  const frozen = stepRace(paused.race, gas, 1, { track, rules }).race;
  assert.equal(frozen.player.z, live.player.z);
  const resumed = resumeRace(frozen);
  assert.equal(resumed.race.status, RaceStatus.RUNNING);
  assert.deepEqual(resumed.events.map(e => e.type), [RaceEvent.RESUMED]);
});

test('pausar fuera de carrera no cambia nada', () => {
  const { race } = setup();
  assert.deepEqual(pauseRace(race), { race, events: [] });
});

test('un choque emite su evento y quita velocidad', () => {
  const { race, track, rules } = setup();
  const slowCar = { id: 7, x: 0, z: 1050, speed: 1000, variant: 0 };
  const start = running(race, { player: createPlayer({ z: 1000, speed: 6000 }), traffic: [slowCar] });
  const { race: after, events } = stepRace(start, gas, 1 / 60, { track, rules });
  const hit = events.find(e => e.type === RaceEvent.COLLISION);
  assert.ok(hit);
  assert.ok(after.player.speed < 6000);
  assert.ok(after.impact > 0);
});

test('un auto que acelera más rápido gana más velocidad en el mismo tiempo', async () => {
  const { vehiclePerformance } = await import('../../src/domain/vehicle.js');
  const world = smallWorld();
  const quick = createRace({ ...world, rng: createRng(1), performance: vehiclePerformance(world.rules, { accelerationTime: 2 }) });
  const slow = createRace({ ...world, rng: createRng(1), performance: vehiclePerformance(world.rules, { accelerationTime: 8 }) });
  const fast = stepRace(running(quick), gas, 1, world).race.player.speed;
  const lazy = stepRace(running(slow), gas, 1, world).race.player.speed;
  assert.ok(fast > lazy);
});

test('la resistencia del auto define cuánta velocidad conserva al chocar', async () => {
  const { vehiclePerformance } = await import('../../src/domain/vehicle.js');
  const world = smallWorld();
  const slowCar = { id: 1, x: 0, z: 1050, speed: 1000, variant: 0 };
  const after = retention => {
    const race = createRace({ ...world, rng: createRng(1), performance: vehiclePerformance(world.rules, { collisionSpeedRetention: retention }) });
    return stepRace(running(race, { player: createPlayer({ z: 1000, speed: 6000 }), traffic: [slowCar] }), gas, 1 / 60, world).race.player.speed;
  };
  assert.ok(after(0.9) > after(0.3));
});

test('la velocidad máxima del auto no altera la velocidad del tráfico', async () => {
  const { vehiclePerformance } = await import('../../src/domain/vehicle.js');
  const world = smallWorld({ trafficCount: 5, trafficSafeStartSegments: 2 });
  const base = createRace({ ...world, rng: createRng(4) });
  const slowCar = createRace({ ...world, rng: createRng(4), performance: vehiclePerformance(world.rules, { maxSpeedRatio: 0.5 }) });
  assert.deepEqual(base.traffic, slowCar.traffic);
});
