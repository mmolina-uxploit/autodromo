import { test } from 'node:test';
import assert from 'node:assert/strict';
import { Track } from '../../src/domain/track.js';
import { SMALL_LAYOUT } from '../helpers.js';

const OPTIONS = { segmentLength: 200, rumbleLength: 3, trackStretch: 1 };
const track = Track.fromLayout(SMALL_LAYOUT, OPTIONS);

test('el circuito empieza y cierra a altura cero', () => {
  assert.equal(track.segment(0).startHeight, 0);
  assert.equal(track.segment(track.segmentCount - 1).endHeight, 0);
});

test('la altura es continua entre segmentos consecutivos', () => {
  for (let i = 1; i < track.segmentCount; i++) {
    assert.equal(track.segment(i).startHeight, track.segment(i - 1).endHeight);
  }
});

test('el largo es la cantidad de segmentos por su longitud', () => {
  assert.equal(track.length, track.segmentCount * 200);
});

test('segmentAt envuelve posiciones fuera del circuito', () => {
  assert.equal(track.segmentAt(track.length + 250).index, 1);
  assert.equal(track.segmentAt(-1).index, track.segmentCount - 1);
});

test('cada tramo entra en curva cero y la sostiene en su parte media', () => {
  assert.equal(track.segment(0).curve, 0);
  for (const i of [2, 3, 4]) assert.equal(track.segment(i).curve, 4);
});

test('las franjas alternan cada rumbleLength segmentos', () => {
  assert.deepEqual([0, 1, 2, 3, 4, 5, 6].map(i => track.segment(i).band), [0, 0, 0, 1, 1, 1, 0]);
});

test('solo los primeros segmentos forman la línea de largada', () => {
  assert.deepEqual([0, 1, 2, 3].map(i => track.segment(i).isStartLine), [true, true, true, false]);
});

test('heightAt interpola dentro del segmento', () => {
  const s = track.segment(3);
  const mid = 3 * 200 + 100;
  assert.ok(Math.abs(track.heightAt(mid) - (s.startHeight + s.endHeight) / 2) < 1e-9);
});

test('trackStretch multiplica los segmentos de cada tramo', () => {
  const stretched = Track.fromLayout(SMALL_LAYOUT, { ...OPTIONS, trackStretch: 2 });
  assert.equal(stretched.segmentCount, track.segmentCount * 2 - 1);
});

test('rechaza un tramo sin segmentos', () => {
  assert.throws(
    () => Track.fromLayout([{ enter: 0, hold: 0, leave: 0, curve: 0, hill: 0 }], OPTIONS),
    /al menos un segmento/
  );
});

test('los segmentos son inmutables', () => {
  assert.throws(() => { 'use strict'; track.segment(0).curve = 9; }, TypeError);
});
