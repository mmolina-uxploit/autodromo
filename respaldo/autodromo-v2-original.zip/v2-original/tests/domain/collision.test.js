import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createRules } from '../../src/config/rules.js';
import { findCollision, resolveCollision } from '../../src/domain/collision.js';
import { createPlayer } from '../../src/domain/player.js';

const rules = createRules();
const LENGTH = 10000;
const car = overrides => ({ id: 1, x: 0, z: 1000, speed: 2000, variant: 0, ...overrides });

test('detecta un auto más lento justo adelante en el mismo carril', () => {
  const player = createPlayer({ z: 950, speed: 5000 });
  assert.equal(findCollision(player, [car()], LENGTH, rules)?.id, 1);
});

test('ignora autos más rápidos que el jugador', () => {
  const player = createPlayer({ z: 950, speed: 1000 });
  assert.equal(findCollision(player, [car()], LENGTH, rules), null);
});

test('ignora autos de otro carril', () => {
  const player = createPlayer({ z: 950, speed: 5000 });
  assert.equal(findCollision(player, [car({ x: 0.66 })], LENGTH, rules), null);
});

test('ignora autos lejanos', () => {
  const player = createPlayer({ z: 950, speed: 5000 });
  assert.equal(findCollision(player, [car({ z: 3000 })], LENGTH, rules), null);
});

test('detecta choques a través de la línea de largada', () => {
  const player = createPlayer({ z: LENGTH - 50, speed: 5000 });
  assert.equal(findCollision(player, [car({ z: 40 })], LENGTH, rules)?.id, 1);
});

test('resolver deja al jugador detrás del auto y más lento', () => {
  const hit = car();
  const player = resolveCollision(createPlayer({ z: 990, speed: 5000 }), hit, LENGTH, rules);
  assert.equal(player.speed, hit.speed * rules.collisionSpeedRetention);
  assert.equal(player.z, hit.z - rules.segmentLength * rules.collisionPushback);
  assert.equal(findCollision(player, [hit], LENGTH, rules), null);
});
