import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createTraffic, advanceTraffic, laneCenters } from '../../src/domain/traffic.js';
import { createRng } from '../../src/domain/rng.js';
import { smallWorld } from '../helpers.js';

const { rules, track } = smallWorld({ trafficCount: 50, trafficSafeStartSegments: 4 });

test('laneCenters reparte la calzada en partes iguales', () => {
  const centers = laneCenters(3);
  assert.equal(centers.length, 3);
  assert.ok(Math.abs(centers[0] + 2 / 3) < 1e-12);
  assert.equal(centers[1], 0);
  assert.ok(Math.abs(centers[2] - 2 / 3) < 1e-12);
});

test('la misma semilla genera el mismo tráfico', () => {
  assert.deepEqual(createTraffic(track, rules, createRng(3), 4), createTraffic(track, rules, createRng(3), 4));
});

test('ningún auto nace en la zona de largada', () => {
  const cars = createTraffic(track, rules, createRng(9), 4);
  const safe = rules.trafficSafeStartSegments * rules.segmentLength;
  assert.ok(cars.every(c => c.z >= safe && c.z < track.length));
});

test('cada auto circula por el centro de un carril', () => {
  const centers = laneCenters(rules.lanes);
  const cars = createTraffic(track, rules, createRng(1), 4);
  assert.ok(cars.every(c => centers.includes(c.x)));
});

test('velocidades y variantes respetan sus rangos', () => {
  const cars = createTraffic(track, rules, createRng(5), 6);
  const min = rules.maxSpeed * rules.trafficMinSpeedRatio;
  const max = rules.maxSpeed * (rules.trafficMinSpeedRatio + rules.trafficSpeedSpreadRatio);
  assert.ok(cars.every(c => c.speed >= min && c.speed <= max));
  assert.ok(cars.every(c => Number.isInteger(c.variant) && c.variant >= 0 && c.variant < 6));
});

test('avanzar envuelve al llegar al final del circuito', () => {
  const [moved] = advanceTraffic([{ id: 0, x: 0, z: track.length - 10, speed: 100, variant: 0 }], 1, track.length);
  assert.equal(moved.z, 90);
});
