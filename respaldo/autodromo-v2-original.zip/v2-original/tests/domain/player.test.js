import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createRules } from '../../src/config/rules.js';
import { createPlayer, stepPlayerPhysics, isOffRoad } from '../../src/domain/player.js';
import { createControls } from '../../src/domain/controls.js';

const rules = createRules();
const gas = createControls({ throttle: 1 });
const brake = createControls({ brake: 1 });
const idle = createControls();

test('acelerar suma velocidad según el tiempo de aceleración', () => {
  const p = stepPlayerPhysics(createPlayer(), gas, 0, 1, rules);
  assert.equal(p.speed, rules.maxSpeed / rules.accelerationTime);
});

test('la velocidad nunca supera la máxima', () => {
  const p = stepPlayerPhysics(createPlayer({ speed: rules.maxSpeed }), gas, 0, 1, rules);
  assert.equal(p.speed, rules.maxSpeed);
});

test('frenar quita velocidad más rápido que soltar los pedales', () => {
  const start = createPlayer({ speed: rules.maxSpeed / 2 });
  const braking = stepPlayerPhysics(start, brake, 0, 0.1, rules);
  const coasting = stepPlayerPhysics(start, idle, 0, 0.1, rules);
  assert.ok(braking.speed < coasting.speed);
  assert.ok(coasting.speed < start.speed);
});

test('el freno manda sobre el acelerador', () => {
  const both = createControls({ throttle: 1, brake: 1 });
  const p = stepPlayerPhysics(createPlayer({ speed: 1000 }), both, 0, 0.1, rules);
  assert.ok(p.speed < 1000);
});

test('la velocidad nunca es negativa', () => {
  const p = stepPlayerPhysics(createPlayer({ speed: 10 }), brake, 0, 1, rules);
  assert.equal(p.speed, 0);
});

test('detenido no puede doblar', () => {
  const p = stepPlayerPhysics(createPlayer(), createControls({ steer: 1 }), 0, 1, rules);
  assert.equal(p.x, 0);
});

test('doblar desplaza en proporción a la velocidad', () => {
  const steer = createControls({ steer: -1 });
  const slow = stepPlayerPhysics(createPlayer({ speed: rules.maxSpeed / 4 }), steer, 0, 0.1, rules);
  const fast = stepPlayerPhysics(createPlayer({ speed: rules.maxSpeed / 2 }), steer, 0, 0.1, rules);
  assert.ok(slow.x < 0);
  assert.ok(Math.abs(fast.x) > Math.abs(slow.x));
});

test('una curva a la derecha empuja el auto hacia la izquierda', () => {
  const p = stepPlayerPhysics(createPlayer({ speed: rules.maxSpeed }), idle, 4, 0.1, rules);
  assert.ok(p.x < 0);
});

test('fuera de la calzada pierde velocidad hasta el límite de banquina', () => {
  const start = createPlayer({ x: 1.5, speed: rules.maxSpeed });
  const offRoad = stepPlayerPhysics(start, gas, 0, 0.1, rules);
  const onRoad = stepPlayerPhysics({ ...start, x: 0 }, gas, 0, 0.1, rules);
  assert.ok(isOffRoad(start));
  assert.ok(offRoad.speed < onRoad.speed);
});

test('el desplazamiento lateral queda limitado', () => {
  const p = stepPlayerPhysics(createPlayer({ x: 1.99, speed: rules.maxSpeed }), createControls({ steer: 1 }), 0, 1, rules);
  assert.equal(p.x, rules.lateralLimit);
});

test('los controles se recortan a sus rangos', () => {
  assert.deepEqual({ ...createControls({ steer: 3, throttle: -1, brake: 2 }) }, { steer: 1, throttle: 0, brake: 1 });
});
