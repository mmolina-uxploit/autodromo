import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createCamera, createViewport, projectPoint, fogAt, spriteScale } from '../../src/infrastructure/rendering/projection.js';

const camera = createCamera({ height: 1000, fieldOfView: 100, drawDistance: 140, fogDensity: 5 });
const viewport = createViewport(800, 1000);

test('la cámara deriva su profundidad del campo visual', () => {
  assert.ok(Math.abs(camera.depth - 1 / Math.tan((50 * Math.PI) / 180)) < 1e-12);
  assert.equal(camera.offset, 1000 * camera.depth);
});

test('el horizonte y la unidad horizontal dependen del viewport', () => {
  assert.equal(viewport.horizon, 320);
  assert.equal(viewport.unit, 620);
});

test('un punto adelante y a la altura de la cámara cae en el horizonte central', () => {
  const p = projectPoint({}, { x: 0, y: 1000, z: 5000 }, { x: 0, y: 1000, z: 0 }, camera, viewport, 2000);
  assert.equal(p.x, 400);
  assert.equal(p.y, viewport.horizon);
});

test('el ancho proyectado se reduce con la distancia', () => {
  const near = projectPoint({}, { x: 0, y: 0, z: 1000 }, { x: 0, y: 1000, z: 0 }, camera, viewport, 2000);
  const far = projectPoint({}, { x: 0, y: 0, z: 4000 }, { x: 0, y: 1000, z: 0 }, camera, viewport, 2000);
  assert.ok(near.w > far.w);
  assert.ok(near.y > far.y);
});

test('la niebla crece con la distancia', () => {
  assert.equal(fogAt(0, 140, 5), 0);
  assert.ok(fogAt(70, 140, 5) < fogAt(140, 140, 5));
  assert.ok(fogAt(140, 140, 5) < 1);
});

test('el sprite del jugador conserva la escala del mundo', () => {
  const scaleAtPlayer = camera.depth / camera.offset;
  const s = spriteScale(scaleAtPlayer, viewport, 330, 100);
  assert.ok(Math.abs(s - (viewport.unit / 2000) * 3.3) < 1e-12);
});
