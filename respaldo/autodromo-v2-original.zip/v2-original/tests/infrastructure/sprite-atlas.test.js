import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { parseAtlas, steerFrameIndex, frameKey, findFrame, loadSpriteAtlas } from '../../src/infrastructure/rendering/sprite-atlas.js';

const json = JSON.parse(readFileSync(new URL('../../assets/sprites/atlas.json', import.meta.url)));
const atlas = parseAtlas(json);

test('parseAtlas expone cuadro, ancla, escala y hojas', () => {
  assert.equal(atlas.frameWidth, json.cuadro.ancho);
  assert.deepEqual([atlas.anchorX, atlas.anchorY], json.cuadro.ancla);
  assert.equal(atlas.pixelsPerMeter, json.px_por_metro_en_ancla);
  assert.deepEqual(Object.keys(atlas.sheets).sort(), ['bloque', 'cuna', 'saeta']);
});

test('steerFrameIndex reparte la dirección entre los cuadros', () => {
  assert.equal(steerFrameIndex(-1, 7), 0);
  assert.equal(steerFrameIndex(0, 7), 3);
  assert.equal(steerFrameIndex(1, 7), 6);
  assert.equal(steerFrameIndex(5, 7), 6);
});

test('frameKey sigue la nomenclatura del contrato de sprites', () => {
  assert.equal(frameKey({ model: 'cuna', livery: 'lima', incline: 'plano', light: 'freno', steerIndex: 3 }), 'cuna_lima_plano_freno_g3');
});

test('findFrame cae en luz y luego en plano cuando falta el cuadro pedido', () => {
  const rect = { x: 0, y: 0, w: 10, h: 10 };
  const synthetic = { sheets: { auto: { image: 'img', frames: { auto_a_plano_luz_g0: rect } } } };
  const frame = findFrame(synthetic, { model: 'auto', livery: 'a', incline: 'subida', light: 'freno', steerIndex: 0 });
  assert.deepEqual(frame, { image: 'img', rect });
});

test('el atlas real tiene freno para todos los modelos', () => {
  for (const model of ['cuna', 'saeta', 'bloque']) {
    const sheet = json.hojas[model];
    assert.ok(Object.keys(sheet.cuadros).some(k => k.includes('_freno_')), model);
  }
});

test('findFrame devuelve null para modelos desconocidos', () => {
  assert.equal(findFrame(atlas, { model: 'tanque', livery: 'x', incline: 'plano', light: 'luz', steerIndex: 0 }), null);
});

test('loadSpriteAtlas carga una imagen por hoja', async () => {
  const loaded = await loadSpriteAtlas('assets/sprites', {
    fetchJson: async () => json,
    loadImage: async url => ({ url })
  });
  assert.equal(loaded.sheets.cuna.image.url, 'assets/sprites/cuna.png');
});
