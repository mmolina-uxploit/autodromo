import { test } from 'node:test';
import assert from 'node:assert/strict';
import { formatLapTime, toKmh, presentHud, describeEvent } from '../../src/application/hud-presenter.js';
import { RaceEvent } from '../../src/domain/race.js';

test('formatLapTime muestra minutos, segundos y centésimas', () => {
  assert.equal(formatLapTime(0), '0:00.00');
  assert.equal(formatLapTime(65.432), '1:05.43');
  assert.equal(formatLapTime(59.999), '1:00.00');
  assert.equal(formatLapTime(null), null);
});

test('toKmh escala la velocidad a una cifra legible', () => {
  assert.equal(toKmh(0, 12000), 0);
  assert.equal(toKmh(12000, 12000), 230);
  assert.equal(toKmh(6000, 12000), 115);
});

test('presentHud arma el modelo de vista', () => {
  const race = { player: { speed: 6000 }, timer: { lap: 2, current: 12.3, best: null } };
  assert.deepEqual(presentHud(race, { maxSpeed: 12000 }), {
    speed: '115', lap: 'Vuelta 2', time: '0:12.30', best: 'sin registro'
  });
});

test('describeEvent redacta anuncios para lector de pantalla', () => {
  assert.equal(describeEvent({ type: RaceEvent.COUNTDOWN_TICK, value: 2 }), '2');
  assert.equal(describeEvent({ type: RaceEvent.STARTED }), 'Largada');
  assert.equal(describeEvent({ type: RaceEvent.LAP_COMPLETED, lap: 1, time: 62.5, isBest: true }), 'Vuelta 1 en 1:02.50. Mejor vuelta.');
  assert.equal(describeEvent({ type: RaceEvent.LAP_COMPLETED, lap: 2, time: 70, isBest: false }), 'Vuelta 2 en 1:10.00.');
  assert.equal(describeEvent({ type: RaceEvent.COLLISION, speedLost: 100 }), 'Choque');
  assert.equal(describeEvent({ type: 'desconocido' }), null);
});
