import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createSettings, updateSettings } from '../../src/application/settings.js';
import { createSettingsStore } from '../../src/application/settings-store.js';

const catalog = {
  tracks: ['t1', 't2'],
  vehicles: ['v1', 'v2'],
  liveries: { v1: ['a', 'b'], v2: ['c'] },
  prefersReducedMotion: false
};

test('sin datos usa los primeros valores del catálogo', () => {
  assert.deepEqual({ ...createSettings({}, catalog) }, {
    track: 't1', vehicle: 'v1', livery: 'a',
    autoThrottle: false, swapControls: false, vibration: true, reducedMotion: false
  });
});

test('el movimiento reducido arranca según la preferencia del sistema', () => {
  assert.equal(createSettings({}, { ...catalog, prefersReducedMotion: true }).reducedMotion, true);
});

test('migra la zona guardada por la versión anterior a la pista equivalente', () => {
  assert.equal(createSettings({ zone: 't2' }, catalog).track, 't2');
});

test('el color tiene que pertenecer al auto elegido', () => {
  assert.equal(createSettings({ vehicle: 'v2', livery: 'a' }, catalog).livery, 'c');
});

test('al cambiar de auto, el color pasa al primero del auto nuevo', () => {
  const previous = createSettings({ vehicle: 'v1', livery: 'b' }, catalog);
  const next = updateSettings(previous, { vehicle: 'v2' }, catalog);
  assert.equal(next.vehicle, 'v2');
  assert.equal(next.livery, 'c');
});

test('un parche puede cambiar auto y color a la vez', () => {
  const next = updateSettings(createSettings({}, catalog), { vehicle: 'v2', livery: 'c' }, catalog);
  assert.deepEqual([next.vehicle, next.livery], ['v2', 'c']);
});

test('los valores inválidos conservan el valor anterior', () => {
  const previous = createSettings({ track: 't2', livery: 'b' }, catalog);
  const next = updateSettings(previous, { track: 'zzz', livery: 'c', vibration: 0 }, catalog);
  assert.deepEqual([next.track, next.livery, next.vibration], ['t2', 'b', true]);
});

test('el almacén carga, guarda y avisa cambios', () => {
  const saved = [];
  const repository = { load: () => ({ vehicle: 'v2' }), save: s => saved.push(s) };
  const store = createSettingsStore({ repository, catalog });
  const seen = [];
  store.subscribe(s => seen.push(s.track));
  assert.equal(store.current.vehicle, 'v2');
  store.update({ track: 't2' });
  assert.deepEqual(seen, ['t2']);
  assert.equal(saved.at(-1).track, 't2');
});
