import { test } from 'node:test';
import assert from 'node:assert/strict';
import { presentVehicleStats, describeTrack } from '../../src/application/selection-presenters.js';
import { Track } from '../../src/domain/track.js';
import { createRules } from '../../src/config/rules.js';

const rules = createRules();

test('las estadísticas del auto van de 1 a 5 y se explican en texto', () => {
  const stats = presentVehicleStats({ performance: { maxSpeedRatio: 1, accelerationTime: 3.5, steeringRate: 2.6, centrifugal: 0.2, collisionSpeedRetention: 0.9 } }, rules);
  assert.deepEqual(stats.map(s => s.label), ['Velocidad', 'Aceleración', 'Manejo', 'Resistencia']);
  assert.deepEqual(stats.map(s => s.value), [5, 5, 5, 5]);
  assert.equal(stats[0].text, '5 de 5');
});

test('los valores bajos dan 1 y los intermedios caen en el medio', () => {
  const low = presentVehicleStats({ performance: { maxSpeedRatio: 0.7, accelerationTime: 9, steeringRate: 1, centrifugal: 0.5, collisionSpeedRetention: 0.3 } }, rules);
  assert.deepEqual(low.map(s => s.value), [1, 1, 1, 1]);
  const mid = presentVehicleStats({ performance: { maxSpeedRatio: 0.9 } }, rules);
  assert.equal(mid[0].value, 3);
});

test('sin ajustes, las estadísticas usan las reglas base', () => {
  const stats = presentVehicleStats({ performance: {} }, rules);
  assert.ok(stats.every(s => s.value >= 1 && s.value <= 5));
});

test('describeTrack resume largo, curvas, desnivel y perfil', () => {
  const layout = [
    { enter: 5, hold: 10, leave: 5, curve: 4, hill: 20 },
    { enter: 5, hold: 10, leave: 5, curve: 0, hill: 0 },
    { enter: 5, hold: 10, leave: 5, curve: -4, hill: -10 }
  ];
  const track = Track.fromLayout(layout, { ...rules, trackStretch: 1 });
  const info = describeTrack(track, rules, 24);
  assert.equal(info.curves, 2);
  assert.match(info.length, /^\d+,\d{2} km$/);
  assert.match(info.elevation, /^\d+ m$/);
  assert.equal(info.profile.length, 24);
  assert.ok(info.profile.every(v => v >= 0 && v <= 1));
  assert.ok(info.bends.some(v => v > 0) && info.bends.some(v => v < 0));
});

test('una pista plana tiene perfil centrado', () => {
  const track = Track.fromLayout([{ enter: 2, hold: 2, leave: 2, curve: 0, hill: 0 }], { ...rules, trackStretch: 1 });
  const info = describeTrack(track, rules, 8);
  assert.ok(info.profile.every(v => v === 0.5));
  assert.equal(info.curves, 0);
});
