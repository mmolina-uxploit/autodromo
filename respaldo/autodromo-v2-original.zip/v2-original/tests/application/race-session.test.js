import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createRaceSession, bestLapKey } from '../../src/application/race-session.js';
import { Action } from '../../src/application/controls-mapper.js';
import { RaceStatus, RaceEvent, SessionEvent } from '../../src/application/race-events.js';
import { createRace } from '../../src/domain/race.js';
import { createRng } from '../../src/domain/rng.js';
import { Track } from '../../src/domain/track.js';
import { createRules } from '../../src/config/rules.js';
import { SMALL_LAYOUT } from '../helpers.js';

const rules = createRules({ trackStretch: 1, trafficCount: 0, countdownSeconds: 1, minLapSeconds: 0.01 });
const tracks = new Map([
  ['corta', Track.fromLayout(SMALL_LAYOUT, rules)],
  ['larga', Track.fromLayout([...SMALL_LAYOUT, ...SMALL_LAYOUT], rules)]
]);
const vehicles = [
  { id: 'agil', performance: { accelerationTime: 2 } },
  { id: 'pesado', performance: { accelerationTime: 8, collisionSpeedRetention: 0.9 } }
];

function makeSession({ settings = {}, records = {}, raceFactory } = {}) {
  const store = new Map(Object.entries(records));
  const pulses = [];
  let current = { track: 'corta', vehicle: 'agil', autoThrottle: false, vibration: true, ...settings };
  const session = createRaceSession({
    tracks, vehicles, rules,
    createRng: () => createRng(1),
    trafficVariants: 1,
    bestLapRepository: { load: key => store.get(key) ?? null, save: (key, t) => store.set(key, t) },
    haptics: { pulse: ms => pulses.push(ms) },
    getSettings: () => current,
    raceFactory
  });
  return { session, store, pulses, select: patch => { current = { ...current, ...patch }; } };
}

const run = (session, seconds, actions = new Set()) => {
  const events = [];
  for (let t = 0; t < seconds; t += 0.05) events.push(...session.tick(0.05, actions).events);
  return events;
};

test('arma el mundo con la pista y el auto elegidos', () => {
  const { session } = makeSession({ settings: { track: 'larga', vehicle: 'pesado' } });
  assert.equal(session.world.track, tracks.get('larga'));
  assert.equal(session.world.vehicleId, 'pesado');
  assert.equal(session.state.performance.collisionSpeedRetention, 0.9);
});

test('una selección desconocida cae en la primera pista y el primer auto', () => {
  const { session } = makeSession({ settings: { track: 'nada', vehicle: 'nadie' } });
  assert.deepEqual([session.world.trackId, session.world.vehicleId], ['corta', 'agil']);
});

test('la mejor vuelta se guarda por combinación de pista y auto', () => {
  const { session, store } = makeSession({ records: { [bestLapKey('corta', 'pesado')]: 50 } });
  assert.equal(session.state.timer.best, null);
  session.start();
  run(session, 1.2);
  run(session, 6, new Set([Action.THROTTLE]));
  assert.ok(store.get(bestLapKey('corta', 'agil')) > 0);
  assert.equal(store.get(bestLapKey('corta', 'pesado')), 50);
});

test('bestLapFor consulta cualquier combinación', () => {
  const { session } = makeSession({ records: { [bestLapKey('larga', 'pesado')]: 71.5 } });
  assert.equal(session.bestLapFor('larga', 'pesado'), 71.5);
  assert.equal(session.bestLapFor('larga', 'agil'), null);
});

test('syncSelection reconstruye el mundo antes de largar y avisa', () => {
  const { session, select } = makeSession({ records: { [bestLapKey('larga', 'agil')]: 40 } });
  const seen = [];
  session.subscribe(e => seen.push(e.type));
  select({ track: 'larga' });
  session.syncSelection();
  assert.equal(session.world.trackId, 'larga');
  assert.equal(session.state.timer.best, 40);
  assert.deepEqual(seen, [SessionEvent.WORLD_CHANGED]);
});

test('syncSelection no hace nada si la selección no cambió', () => {
  const { session } = makeSession();
  const seen = [];
  session.subscribe(e => seen.push(e.type));
  session.syncSelection();
  assert.deepEqual(seen, []);
});

test('durante la carrera la selección no cambia el mundo', () => {
  const { session, select } = makeSession();
  session.start();
  select({ vehicle: 'pesado' });
  session.syncSelection();
  assert.equal(session.world.vehicleId, 'agil');
  assert.equal(session.state.status, RaceStatus.COUNTDOWN);
});

test('salir al menú aplica la selección pendiente', () => {
  const { session, select } = makeSession();
  session.start();
  select({ vehicle: 'pesado' });
  session.reset();
  assert.equal(session.world.vehicleId, 'pesado');
  assert.equal(session.state.status, RaceStatus.READY);
});

test('start pasa por la cuenta regresiva y larga', () => {
  const { session } = makeSession();
  const seen = [];
  session.subscribe(e => seen.push(e.type));
  session.start();
  run(session, 1.2);
  assert.equal(session.state.status, RaceStatus.RUNNING);
  assert.deepEqual(seen, [RaceEvent.COUNTDOWN_TICK, RaceEvent.STARTED]);
});

test('tick devuelve los controles aplicados', () => {
  const { session } = makeSession({ settings: { autoThrottle: true } });
  const { controls } = session.tick(0.05, new Set([Action.LEFT]));
  assert.deepEqual([controls.steer, controls.throttle], [-1, 1]);
});

test('un choque vibra solo si la vibración está activa', () => {
  for (const vibration of [true, false]) {
    const slowCar = Object.freeze({ id: 1, x: 0, z: 400, speed: 300, variant: 0 });
    const raceFactory = args => ({ ...createRace(args), traffic: [slowCar] });
    const { session, pulses } = makeSession({ settings: { vibration }, raceFactory });
    session.start();
    run(session, 1.2);
    const events = run(session, 2, new Set([Action.THROTTLE]));
    assert.ok(events.some(e => e.type === RaceEvent.COLLISION));
    assert.equal(pulses.length > 0, vibration);
  }
});

test('togglePause alterna entre pausa y carrera', () => {
  const { session } = makeSession();
  session.start();
  run(session, 1.2);
  session.togglePause();
  assert.equal(session.state.status, RaceStatus.PAUSED);
  session.togglePause();
  assert.equal(session.state.status, RaceStatus.RUNNING);
});

test('restart arma una carrera nueva en cuenta regresiva', () => {
  const { session } = makeSession();
  session.start();
  run(session, 2, new Set([Action.THROTTLE]));
  session.restart();
  assert.equal(session.state.status, RaceStatus.COUNTDOWN);
  assert.equal(session.state.player.z, 0);
});
