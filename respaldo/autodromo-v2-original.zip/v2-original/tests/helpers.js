import { createRules } from '../src/config/rules.js';
import { Track } from '../src/domain/track.js';

export const SMALL_LAYOUT = Object.freeze([
  { enter: 2, hold: 3, leave: 2, curve: 4, hill: 10 },
  { enter: 2, hold: 2, leave: 2, curve: -3, hill: -4 }
]);

export function smallWorld(overrides = {}) {
  const rules = createRules({ trackStretch: 1, trafficCount: 0, ...overrides });
  const track = Track.fromLayout(SMALL_LAYOUT, rules);
  return { rules, track };
}
