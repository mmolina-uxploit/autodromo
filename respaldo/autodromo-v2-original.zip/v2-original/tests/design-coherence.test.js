import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { ZONES, TRAFFIC_VARIANTS } from '../src/config/zones.js';
import { VEHICLES } from '../src/config/vehicles.js';
import { TRACKS } from '../src/config/tracks.js';

const read = path => readFileSync(new URL(path, import.meta.url), 'utf8');
const eco = JSON.parse(read('../design/ecosistema.json'));
const atlas = JSON.parse(read('../assets/sprites/atlas.json'));

test('las zonas del juego son las del ecosistema, con los mismos colores', () => {
  assert.deepEqual(ZONES.map(z => z.id), eco.zonas.map(z => z.id));
  for (const zone of ZONES) {
    const source = eco.zonas.find(z => z.id === zone.id);
    assert.equal(zone.name, source.nombre);
    assert.deepEqual(zone.sky, source.cielo);
    assert.equal(zone.fog, source.niebla);
    assert.deepEqual(zone.road.asphalt, source.pista.asfalto);
    assert.deepEqual(zone.road.rumble, source.pista.cordon);
    assert.equal(zone.road.lane, source.pista.carril);
    assert.deepEqual(zone.road.ground, source.pista.suelo);
  }
});

test('cada pista usa una zona existente y tiene trazado propio', () => {
  const ids = TRACKS.map(t => t.id);
  assert.equal(new Set(ids).size, ids.length);
  const layouts = new Set(TRACKS.map(t => JSON.stringify(t.layout)));
  assert.equal(layouts.size, TRACKS.length);
  for (const track of TRACKS) assert.ok(ZONES.some(z => z.id === track.zone), track.id);
});

test('los autos elegibles son los del ecosistema, con sus libreas canónicas', () => {
  assert.deepEqual(VEHICLES.map(v => v.id), Object.keys(eco.vehiculos));
  for (const vehicle of VEHICLES) {
    const canon = eco.vehiculos[vehicle.model];
    assert.equal(vehicle.name, canon.nombre);
    assert.deepEqual(vehicle.liveries.map(l => [l.id, l.swatch]), canon.libreas.map(l => [l.id, l.carroceria]));
  }
});

test('cada librea elegible tiene sprites de luz y freno en todos los giros, y su retrato', () => {
  const steps = atlas.giros_grados.length;
  for (const { model, liveries } of VEHICLES) {
    const frames = atlas.hojas[model]?.cuadros ?? {};
    for (const { id } of liveries) {
      for (let g = 0; g < steps; g++) {
        for (const light of ['luz', 'freno']) {
          assert.ok(frames[`${model}_${id}_plano_${light}_g${g}`], `${model}/${id} ${light} giro ${g}`);
        }
      }
      assert.ok(existsSync(new URL(`../assets/garage/${model}-${id}.png`, import.meta.url)), `retrato ${model}-${id}`);
    }
  }
});

test('el tráfico usa libreas que existen en el atlas', () => {
  for (const { model, livery } of TRAFFIC_VARIANTS) {
    assert.ok(atlas.hojas[model]?.cuadros[`${model}_${livery}_plano_luz_g3`], `${model}/${livery}`);
  }
});

test('los colores de los tokens CSS salen de la paleta del ecosistema', () => {
  const palette = new Set(Object.values(eco.paleta).flat().map(c => c.hex.toLowerCase()));
  const tokens = [...read('../styles/tokens.css').matchAll(/--color-[\w-]+:\s*(#[0-9a-fA-F]{6})/g)].map(m => m[1].toLowerCase());
  assert.ok(tokens.length > 0);
  for (const hex of tokens) assert.ok(palette.has(hex), `${hex} no está en la paleta`);
});
