/**
 * Prueba de humo de punta a punta con navegador real (Playwright + axe-core).
 * Uso: npm install && npm run e2e   (opcional: CHROMIUM_PATH=/ruta/al/chrome)
 * Deja capturas en tests/e2e/capturas/.
 */
import { createServer } from 'node:http';
import { readFile, mkdir } from 'node:fs/promises';
import { extname, join, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import { chromium, devices } from 'playwright';

const ROOT = fileURLToPath(new URL('../../', import.meta.url));
const SHOTS = join(ROOT, 'tests/e2e/capturas');
const AXE = createRequire(import.meta.url).resolve('axe-core/axe.min.js');
const TYPES = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.png': 'image/png' };

const failures = [];
const check = (ok, message) => { console.log(`${ok ? '✓' : '✗'} ${message}`); if (!ok) failures.push(message); };

function serve() {
  const server = createServer(async (req, res) => {
    const path = normalize(decodeURIComponent(new URL(req.url, 'http://x').pathname)).replace(/^([/\\])+/, '');
    const file = path || 'index.html';
    try {
      const body = await readFile(join(ROOT, file));
      res.writeHead(200, { 'content-type': TYPES[extname(file)] ?? 'application/octet-stream' });
      res.end(body);
    } catch {
      res.writeHead(404).end();
    }
  });
  return new Promise(resolve => server.listen(0, () => resolve(server)));
}

async function axeScan(page, label) {
  await page.addScriptTag({ path: AXE });
  const result = await page.evaluate(async () => {
    const r = await window.axe.run(document, { runOnly: ['wcag2a', 'wcag2aa', 'wcag21aa'] });
    return r.violations.map(v => `${v.id} (${v.nodes.length}): ${v.help}`);
  });
  check(result.length === 0, `axe ${label}: ${result.length ? result.join(' | ') : 'sin violaciones WCAG A/AA'}`);
}

const speedOf = page => page.locator('.o-hud .a-readout--xl').innerText().then(Number);

/** Velocidad máxima observada mientras se sostiene un control: un choque con tráfico no la invalida. */
async function peakSpeed(page, ms) {
  let peak = 0;
  for (let t = 0; t < ms; t += 100) {
    peak = Math.max(peak, await speedOf(page));
    await page.waitForTimeout(100);
  }
  return peak;
}

async function desktop(browser, url) {
  const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  page.on('console', m => {
    const external = /fonts\.(googleapis|gstatic)\.com/.test(m.location().url ?? '');
    if (m.type() === 'error' && !external) errors.push(`${m.text()} ${m.location().url ?? ''}`);
  });
  await page.goto(url);

  const menu = page.getByRole('dialog', { name: 'Autódromo' });
  await menu.waitFor();
  check(await page.evaluate(() => document.activeElement?.textContent.trim()) === 'Largar', 'el foco inicial está en Largar');
  await page.waitForTimeout(600);
  await page.screenshot({ path: join(SHOTS, 'escritorio-menu.png') });
  await axeScan(page, 'menú de inicio');

  await page.keyboard.press('Shift+Tab');
  check((await page.evaluate(() => document.activeElement?.getAttribute('aria-label') ?? '')).startsWith('Cambiar pista'), 'Shift+Tab desde Largar llega a la ficha de pista');

  // Selección de auto con teclado
  await page.getByRole('button', { name: /^Cambiar auto/ }).press('Enter');
  const cars = page.getByRole('dialog', { name: 'Elegí auto' });
  check(await cars.isVisible(), 'la ficha de auto abre el garaje');
  check(await page.evaluate(() => document.activeElement?.value) === 'cuna', 'el foco va al auto elegido');
  await page.keyboard.press('ArrowDown');
  check(await page.evaluate(() => document.activeElement?.value) === 'saeta', 'las flechas recorren los autos');
  check(await page.getByRole('group', { name: 'Color de Saeta' }).isVisible(), 'los colores cambian al auto elegido');
  check(await page.getByRole('meter', { name: 'Aceleración' }).first().getAttribute('aria-valuetext') !== null, 'las estadísticas se exponen como medidores');
  await page.keyboard.press('Tab');
  await page.keyboard.press('ArrowRight');
  check(await page.evaluate(() => document.activeElement?.value) === 'grafito', 'las flechas eligen el color');
  check(await page.evaluate(() => document.activeElement?.name) === 'color-auto', 'elegir color no le quita el foco al grupo');
  await page.waitForTimeout(400);
  await page.screenshot({ path: join(SHOTS, 'escritorio-garaje.png') });
  await axeScan(page, 'garaje');
  await page.keyboard.press('Escape');
  check(await menu.isVisible(), 'Escape vuelve del garaje al inicio');
  check(/Saeta/.test(await page.getByRole('button', { name: /^Cambiar auto/ }).getAttribute('aria-label')), 'el inicio muestra el auto nuevo');

  // Selección de pista
  await page.getByRole('button', { name: /^Cambiar pista/ }).click();
  const circuits = page.getByRole('dialog', { name: 'Elegí pista' });
  check(await circuits.isVisible(), 'la ficha de pista abre la selección de pistas');
  check(await page.evaluate(() => document.activeElement?.value) === 'bajo-autopista', 'el foco va a la pista elegida');
  await page.keyboard.press('ArrowDown');
  check(await page.evaluate(() => document.activeElement?.value) === 'costa-rosa', 'las flechas recorren las pistas');
  check(await circuits.getByText('Sin vueltas con Saeta').first().isVisible(), 'cada pista informa la mejor vuelta con el auto elegido');
  await page.waitForTimeout(400);
  await page.screenshot({ path: join(SHOTS, 'escritorio-pistas.png') });
  await axeScan(page, 'selección de pista');
  await page.getByRole('button', { name: 'Listo' }).click();
  check(/Costa Rosa/.test(await page.getByRole('button', { name: /^Cambiar pista/ }).getAttribute('aria-label')), 'el inicio muestra la pista nueva');
  await page.waitForTimeout(300);
  await page.screenshot({ path: join(SHOTS, 'escritorio-menu-eleccion.png') });

  await page.getByRole('button', { name: 'Largar' }).focus();
  await page.keyboard.press('Enter');
  check(!(await menu.isVisible()), 'Enter en Largar cierra el menú');
  await page.waitForTimeout(3300);
  await page.keyboard.down('ArrowUp');
  check((await peakSpeed(page, 2500)) > 60, 'mantener ↑ acelera el auto');
  await page.keyboard.down('ArrowLeft');
  await page.waitForTimeout(250);
  await page.screenshot({ path: join(SHOTS, 'escritorio-carrera.png') });
  await page.keyboard.up('ArrowLeft');
  await page.keyboard.up('ArrowUp');

  await page.keyboard.press('Escape');
  const pause = page.getByRole('dialog', { name: 'Pausa' });
  check(await pause.isVisible(), 'Escape abre la pausa');
  check(await page.evaluate(() => document.activeElement?.textContent.trim()) === 'Seguir', 'el foco va a Seguir');
  const frozen = await speedOf(page);
  await page.waitForTimeout(400);
  check((await speedOf(page)) === frozen, 'en pausa la velocidad queda congelada');
  await page.screenshot({ path: join(SHOTS, 'escritorio-pausa.png') });
  await axeScan(page, 'menú de pausa');

  await page.getByRole('button', { name: 'Ajustes' }).click();
  const settings = page.getByRole('dialog', { name: 'Ajustes' });
  check(await settings.isVisible(), 'Ajustes se abre desde la pausa');
  const auto = page.getByRole('switch', { name: 'Aceleración automática' });
  await auto.press('Space');
  check(await auto.getAttribute('aria-checked') === 'true', 'Espacio activa un interruptor');
  await page.screenshot({ path: join(SHOTS, 'escritorio-ajustes.png') });
  await axeScan(page, 'ajustes');
  await auto.press('Space');
  await page.keyboard.press('Escape');
  check(await pause.isVisible(), 'Escape en Ajustes vuelve a la pausa');
  await page.keyboard.press('Escape');
  check(!(await pause.isVisible()), 'Escape en la pausa reanuda la carrera');

  check(errors.length === 0, `sin errores de consola${errors.length ? ': ' + errors.join(' | ') : ''}`);
  await page.close();
}

const overflowing = page => page.evaluate(() =>
  [...document.querySelectorAll('.o-hud *, .o-touch *, dialog[open] *')]
    .filter(e => e.getClientRects().length)
    .filter(e => { const r = e.getBoundingClientRect(); return r.right > innerWidth + 1 || r.left < -1; })
    .map(e => e.className || e.tagName));

async function mobile(browser, url, device = 'iPhone 13') {
  const context = await browser.newContext({ ...devices[device] });
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', e => errors.push(e.message));
  await page.goto(url);
  await page.getByRole('dialog', { name: 'Autódromo' }).waitFor();
  await page.waitForTimeout(600);
  await page.screenshot({ path: join(SHOTS, `movil-menu-${device}.png`.replaceAll(' ', '-')) });
  const menuOverflow = await overflowing(page);
  check(menuOverflow.length === 0, `${device}: el menú entra en pantalla${menuOverflow.length ? ' (se salen: ' + menuOverflow.join(', ') + ')' : ''}`);
  const collisions = await page.$$eval('.m-summary', tiles => tiles.filter(tile => {
    const text = tile.querySelector('.m-summary__text').getBoundingClientRect();
    const action = tile.querySelector('.m-summary__action').getBoundingClientRect();
    const range = document.createRange();
    range.selectNodeContents(tile.querySelector('.m-summary__text'));
    const lines = [...range.getClientRects()].map(r => r.right);
    return Math.max(text.right, ...lines) > action.left + 0.5;
  }).length);
  check(collisions === 0, `${device}: en las fichas del inicio el texto no se monta sobre la flecha`);

  for (const [tile, title, pick] of [['Cambiar auto', 'Elegí auto', 'Bloque'], ['Cambiar pista', 'Elegí pista', 'Anillo Neón']]) {
    await page.getByRole('button', { name: new RegExp(`^${tile}`) }).tap();
    await page.getByRole('dialog', { name: title }).waitFor();
    await page.getByRole('radio', { name: pick }).tap();
    await page.waitForTimeout(400);
    const shotName = `movil-${title.split(' ')[1]}-${device}.png`.replaceAll(' ', '-');
    await page.screenshot({ path: join(SHOTS, shotName) });
    const selectorOverflow = await overflowing(page);
    check(selectorOverflow.length === 0, `${device}: «${title}» entra en pantalla${selectorOverflow.length ? ' (se salen: ' + selectorOverflow.join(', ') + ')' : ''}`);
    check(await page.getByRole('radio', { name: pick }).isChecked(), `${device}: tocar una tarjeta la elige (${pick})`);
    await page.getByRole('button', { name: 'Listo' }).tap();
  }

  check(await page.getByRole('button', { name: 'Acelerar' }).isVisible(), 'en táctil se muestran los pedales');
  const sizes = await page.$$eval('.a-pad, .a-button, .a-chip', els => els.filter(e => e.offsetParent).map(e => Math.min(e.offsetWidth, e.offsetHeight)));
  check(Math.min(...sizes) >= 44, `objetivos táctiles de al menos 44 px (mínimo ${Math.min(...sizes)})`);

  await page.getByRole('button', { name: 'Largar' }).tap();
  await page.waitForTimeout(3300);
  const gas = page.getByRole('button', { name: 'Acelerar' });
  const left = page.getByRole('button', { name: 'Izquierda' });
  await gas.dispatchEvent('pointerdown', { pointerId: 1, pointerType: 'touch', isPrimary: true });
  await left.dispatchEvent('pointerdown', { pointerId: 2, pointerType: 'touch' });
  check((await peakSpeed(page, 2200)) > 50, 'mantener Acelerar acelera, con dos dedos a la vez');
  const raceOverflow = await overflowing(page);
  check(raceOverflow.length === 0, `${device}: tablero y controles entran en pantalla${raceOverflow.length ? ' (se salen: ' + raceOverflow.join(', ') + ')' : ''}`);
  check(await gas.evaluate(e => e.classList.contains('is-pressed')), 'el pedal muestra que está presionado');
  await page.screenshot({ path: join(SHOTS, `movil-carrera-${device}.png`.replaceAll(' ', '-')) });
  await gas.dispatchEvent('pointerup', { pointerId: 1, pointerType: 'touch' });
  await left.dispatchEvent('pointerup', { pointerId: 2, pointerType: 'touch' });
  check(!(await gas.evaluate(e => e.classList.contains('is-pressed'))), 'soltar libera el pedal');

  await page.getByRole('button', { name: 'Pausa' }).tap();
  await page.getByRole('button', { name: 'Ajustes' }).tap();
  await page.getByRole('switch', { name: 'Invertir controles táctiles' }).tap();
  await page.getByRole('button', { name: 'Listo' }).tap();
  await page.getByRole('button', { name: 'Seguir' }).tap();
  check(await page.locator('.o-touch').evaluate(e => e.classList.contains('o-touch--swapped')), 'invertir controles cambia los lados');
  await page.waitForTimeout(300);
  await page.screenshot({ path: join(SHOTS, `movil-invertido-${device}.png`.replaceAll(' ', '-')) });

  check(errors.length === 0, `móvil sin errores${errors.length ? ': ' + errors.join(' | ') : ''}`);
  await context.close();
}

await mkdir(SHOTS, { recursive: true });
const server = await serve();
const url = `http://localhost:${server.address().port}/?semilla=7`;
const browser = await chromium.launch(process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {});
try {
  await desktop(browser, url);
  await mobile(browser, url, 'iPhone 13');
  await mobile(browser, url, 'Galaxy S8');
} finally {
  await browser.close();
  server.close();
}
console.log(failures.length ? `\n${failures.length} verificaciones fallaron` : '\nTodas las verificaciones pasaron');
process.exit(failures.length ? 1 : 0);
